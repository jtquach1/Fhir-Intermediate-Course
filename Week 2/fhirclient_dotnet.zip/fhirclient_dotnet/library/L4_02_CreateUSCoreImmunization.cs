using Hl7.Fhir.Model; 
using Hl7.Fhir.Rest; 
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace fhirclient_dotnet
{
    public class CreateUSCoreImm
    {
        public string CreateUSCoreR4Immunization
        (string ServerEndpoint,
         string PatientIdentifierSystem,
         string PatientIdentifierValue,
         string ImmunizationStatusCode,
         string ImmunizationDateTime,
         string ProductCVXCode,
         string ProductCVXDisplay,
         string ReasonCode)
        {

            string aux="";
            return aux;
        }   
    }
}
