using Hl7.Fhir.Model; 
using Hl7.Fhir.Rest; 
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Net.Http; 
using System.Net.Http.Headers;

namespace fhirclient_dotnet
{
    public class TerminologyService
    {
        public String ExpandValueSetForCombo(
            string EndPoint,
            string Url,
            string Filter

        )
        {
            
            string aux="";
            return aux;

        }

    }
}
