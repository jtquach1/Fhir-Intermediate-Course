package fhir_intermediate_examples;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.rest.api.MethodOutcome;
import ca.uhn.fhir.rest.client.api.IGenericClient;
import com.sun.tools.javac.jvm.Code;
import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.instance.model.api.IIdType;
import org.hl7.fhir.r4.model.*;

import java.util.List;

public class EX_J01_CreateConditionInstance {

   public static void main(String[] args) {
      // Create a context
      FhirContext ctx = FhirContext.forR4();

      // Create a client
      IGenericClient client = ctx.newRestfulGenericClient("http://fhir.hl7fundamentals.org/r4");

      // Step 1 - Create the instance and populate it
      //The Resource
      Condition co;
      co=new Condition();
      //We will fill our element with an element of the Type defined by FHIR so we create one
      CodeableConcept cc;
      cc=new CodeableConcept();
      //And populate it
      cc.addCoding().setCode("44054006").setSystem("http://snomed.info/sct");
      //We fill the resource element. Since its only one, we do set
      co.setClinicalStatus(cc);
      //First stage
      //We declare and initialize the intermediate 'component' object
      Condition.ConditionStageComponent coStage;
      coStage=new Condition.ConditionStageComponent();
      //We declare the objects
      CodeableConcept ccStageSummary=new CodeableConcept();
      CodeableConcept ccStageType=new CodeableConcept();
      Reference reAssessment=new Reference();
      //A diagnostic report
      //We populate the Summary
      ccStageSummary.addCoding().setCode("422375001").setSystem("http://snomed.info/sct").setDisplay("Carcinoma of Colon, Clinical stage III");
      //Populating the Type of Stage
      ccStageType.addCoding().setCode("385356007").setSystem("http://snomed.info/sct").setDisplay("Tumor Stage Finding");
      //For simplicity sake, we just set the reference to a DiagnosticReport
      String sRef="DiagnosticReport/201992";

      reAssessment.setReference(sRef);

      coStage.setSummary(ccStageSummary);
      coStage.setType(ccStageType);
      coStage.addAssessment(reAssessment);   //We add because it can be more than one
      co.addStage(coStage);

      // The same effect can be achieved with the fluent syntax, in a more compact way
      co.addStage()
         .setType(new CodeableConcept().addCoding(new Coding().setCode("422375001").setSystem("http://snomed.info/sct").setDisplay("Carcinoma of Colon, Clinical stage III")))
         .setSummary(new CodeableConcept().addCoding(new Coding().setCode("385356007").setSystem("http://snomed.info/sct").setDisplay("Tumor Stage Finding")))
         .addAssessment(new Reference().setReference("DiagnosticReport/201993"))
         ;
      //OnSet : Age
      co.setOnset(new Age().setValue(18).setCode("Y").setUnit("Y"));
      //OnSet : Date Time
      DateTimeType d=new DateTimeType();
      co.setOnset(d.parseV3("20190213103000"));
      // Step 2 - Invoke the server create method
      MethodOutcome outcome = client.create()
         .resource(co)
         .execute();

      // Step 3 - Obtain the Server's assigned id if the operation was successful
      if (outcome.getCreated()) {
         IIdType id = outcome.getId();
         {
            System.out.println("Created condition, got ID: " + id);
         }
      }
      else
      {
         System.out.println("Error "+outcome.getOperationOutcome().toString() );

      }
   }

}
