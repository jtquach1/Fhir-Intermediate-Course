package fhir_intermediate_examples;
import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.rest.api.MethodOutcome;
import ca.uhn.fhir.rest.client.api.IGenericClient;
import org.hl7.fhir.r4.model.*;
import org.hl7.fhir.instance.model.api.IIdType;
//These are for photo downloading
import java.net.URL;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class EX_J06_UpdatePractitionerInstance
{

   public static void main(String[] args) {
      // Create a context
      FhirContext ctx = FhirContext.forR4();

      // Create a client
      IGenericClient client = ctx.newRestfulGenericClient("http://fhir.hl7fundamentals.org/r4");

      /* Direct Read for a Practitioner resource */
      Practitioner oldDoctor = client.read().resource(Practitioner.class).withId("74329").execute();

      // Print the output
      String string = ctx.newXmlParser().setPrettyPrint(true).encodeResourceToString(oldDoctor);
      System.out.println("Resource Just Read, With Id");
      System.out.println(string);

      /* Add the practitioner photo */

      Attachment photo =new Attachment();
      String url="https://www.clipartwiki.com/clipimg/full/74-743389_female-icon-free-doctor-png-icon.png";

      byte[] photorep= new byte[0];
      try {
         photorep = GetPhoto(url);
      } catch (IOException e) {
         e.printStackTrace();
      }
      photo.setData(photorep)
        .setContentType("image/png")
         .setSize(photorep.length);

      oldDoctor.addPhoto(photo);

      // Step 2 - Invoke the server update method
      MethodOutcome outcome = client.update()
         .resource(oldDoctor)
         .execute();

      // Step 3 - Obtain the Server's assigned id if the operation was successful
      String version = outcome.getId().getVersionIdPart();
      {
         System.out.println("Updated practitioner, got version: " + version);
      }
      /* Direct Read for the Practitioner resource */
      Practitioner newDoctor=new Practitioner();
      newDoctor = client.read().resource(Practitioner.class).withId("74329").execute();

      // Print the output
      String updstring = ctx.newXmlParser().setPrettyPrint(true).encodeResourceToString(newDoctor);
      System.out.println("Resource After Update, With Id/Version");
      System.out.println(updstring);

   }
   private static byte[] GetPhoto (String urlAddress) throws IOException {
   ByteArrayOutputStream baos = new ByteArrayOutputStream();
   InputStream is = null;
   URL url=new URL(urlAddress);
   try
   {
      is = url.openStream ();
      byte[] byteChunk = new byte[4096]; // Or whatever size you want to read in at a time.
      int n;

      while ( (n = is.read(byteChunk)) > 0 ) {
      baos.write(byteChunk, 0, n);
      }
      }
      catch (IOException e) {
      System.err.printf ("Failed while reading bytes from %s: %s", url.toExternalForm(), e.getMessage());
      e.printStackTrace ();
      }
      finally {
      if (is != null) { is.close(); }
      }
      return baos.toByteArray();
 }
}
