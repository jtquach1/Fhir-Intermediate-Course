package fhir_intermediate_examples;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.rest.api.CacheControlDirective;
import ca.uhn.fhir.rest.client.api.IGenericClient;
import org.hl7.fhir.r4.model.*;

public class EX_J40_SearchPractitioner {

   /*This example implements searches for three use cases in Argonaut PD Guide
   A.Search for Practitioner by demographics
      A.1. Name
      A.2.Specialty
   B. Search for Practitioner within a region (city, state)
      B.1 Show me practitioners near me
      B.2 Show me every one of this specialty in the city
   C. Search for Practitioner by identifier
      C.1 Practitioner search by Identifier
    */
   public static void main(String[] args) {
      // Create a context
      FhirContext ctx = FhirContext.forR4();

      // Create a client
      IGenericClient client = ctx.newRestfulGenericClient("http://fhir.hl7fundamentals.org/r4");
      /* The easiest way is to include the URL in the search

       */
      //A.1 Search By Name using byURL
      String searchString = "Practitioner?name=Smith";
      Bundle bu1 = client
         .search()
         .byUrl(searchString)
         .returnBundle(Bundle.class)
         .execute();


      //Print the Bundle result
      //System.out.println(ctx.newJsonParser().setPrettyPrint(true).encodeResourceToString(bu1));

      //A.1 Search By Name using criterion

      Bundle bu2=client.search().forResource(Practitioner.class).and(Practitioner.NAME.matches().value("SMITH"))
            .returnBundle(Bundle.class)
            .execute();
      //Print the Bundle result
      //System.out.println(ctx.newJsonParser().setPrettyPrint(true).encodeResourceToString(bu2));

      //A.2 Search By Specialty using url
      String searchString2 = "PractitionerRole?specialty=http://snomed.info/sct|408443003";
      Bundle bu3 = client
         .search()
         .byUrl(searchString2)
         .cacheControl(new CacheControlDirective().setMaxResults(100))
         .count(10)
         .returnBundle(Bundle.class)
         .execute();
      //Print the Bundle result
      System.out.println(ctx.newJsonParser().setPrettyPrint(true).encodeResourceToString(bu3));

      //A.2 Search By Specialty using criterion
      Bundle bu4 = client
         .search()
         .forResource(PractitionerRole.class)
         .and(PractitionerRole.SPECIALTY.exactly().systemAndCode("http://snomed.info/sct","408443003"))
         .returnBundle(Bundle.class)
         .execute();
      System.out.println(ctx.newJsonParser().setPrettyPrint(true).encodeResourceToString(bu4));

      //B.1 Search By Specialty near me, using URL
      //Watch out for this - very few servers support this syntax
      //in fact, only test.fhir.org/r3 does
      /*
      String searchString3 = "PractitionerRole?specialty=http://snomed.info/sct|408443003&location.near=%2D34.61315%3A%2D58.37723&location.near-distance=10km";
      Bundle bu5 = client
         .search()
         .byUrl(searchString3)
         .returnBundle(Bundle.class)
         .execute();
      */
      //B.2 Search by specialty in one specific city
/*
      String searchString4 = "PractitionerRole?specialty=http://snomed.info/sct|408443003&organization.address-city=Oklahoma&organization.address-state=Oklahoma";
      Bundle bu6 = client
         .search()
         .byUrl(searchString4)
         .returnBundle(Bundle.class)
         .execute();
      System.out.println(ctx.newJsonParser().setPrettyPrint(true).encodeResourceToString(bu6));
*/

      Bundle bu7 = client
         .search()
         .forResource(PractitionerRole.class)
         .and(Organization.ADDRESS_CITY.matches().value("Oklahoma City"))
         .and(Organization.ADDRESS_STATE.matches().value("Oklahoma"))
         .and(PractitionerRole.SPECIALTY.exactly().systemAndCode("http://snomed.info/sct","40844300"))
         .returnBundle(Bundle.class)
         .execute();
      System.out.println(ctx.newJsonParser().setPrettyPrint(true).encodeResourceToString(bu7));


   }
}
