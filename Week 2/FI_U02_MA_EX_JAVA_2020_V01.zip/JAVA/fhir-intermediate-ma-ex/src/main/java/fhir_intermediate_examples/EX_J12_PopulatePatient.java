package fhir_intermediate_examples;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.rest.api.MethodOutcome;
import ca.uhn.fhir.rest.client.api.IGenericClient;
import com.sun.tools.javac.jvm.Code;
import org.hl7.fhir.r4.model.*;
import org.hl7.fhir.instance.model.api.IIdType;

import java.nio.charset.Charset;
import java.util.Date;

public class EX_J12_PopulatePatient {

   /* This class populates a Patient resource, creates the resource in the server
      if it is not there already, and then relates the resource to a new observation
      and creates the observation


   Name:
      [use] Official [Prefix] Ms. [Given] Eve [Family] Everywoman, [Suffix] III
      Photo: data (base64): iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAC0lEQVR4nGNgAAIAAAUAAXpeqz8=
      Identifiers
      [system] http://hospital.gov/patients [value] 9999999 (Secondary)
      [system] http://citizens-id.gov/citizens [value] 69999999-I (Official)
      Address
      9999 Patient Street, Ann Arbor, MI (90210), USA
      Phone
      (777) 555-9999
      e-mail Address
      eve@everywoman.com
      Gender: Female
      Active: No
      Death Time/Date: Feb 13, 2019 10:30:00
      Marital Status: Widow
      Born : July 23, 1968
      Preferred Language: English (USA). Also speaks Spanish
      Organization in Charge: Ann Arbor General Hospital  - 9999 General Hospital Street, Ann Arbor, MI (90210), USA
                              National Provider Identifier: 999999 (www.npi.org/identifiers)

      Observation: Lab - Fasting Serum Glucose Value: 6,3 mmol/L, Jan 20 20 07:00:00 EST
      14771-0 http://loinc.org
    */
   public static void main(String[] args) {
      // Create a context
      FhirContext ctx = FhirContext.forR4();

      // Create a client
      IGenericClient client = ctx.newRestfulGenericClient("http://fhir.hl7fundamentals.org/r4");

      // Step 1 - Create the instance and populate it

   Patient p;
   p=new Patient();

   //Full Name
   p.addName().addGiven("Eve").setFamily("Everywoman").
      addSuffix("III").addPrefix("Ms.").setUse(HumanName.NameUse.OFFICIAL);

   //Identifiers
   p.addIdentifier(new Identifier().setSystem("http://citizens-id.gov/citizens").setValue("69999999-I").setUse(Identifier.IdentifierUse.OFFICIAL));
   p.addIdentifier(new Identifier().setSystem("http://hospital.gov/patients").setValue("9999999").setUse(Identifier.IdentifierUse.SECONDARY));

   //Address
   Address a=new Address();
   a.addLine("9999 Patient Street").setCity("Ann Arbor").setCountry("US").setState("MI").setPostalCode("90210");
   p.addAddress(a);

   //Phone
   p.addTelecom().setSystem(ContactPoint.ContactPointSystem.PHONE).setValue("(777) 555-9999");

   //E-Mail Address
   p.addTelecom().setSystem(ContactPoint.ContactPointSystem.EMAIL).setValue("eve@everywoman.com");

   //Gender
   p.setGender(Enumerations.AdministrativeGender.FEMALE);

   //Active
   p.setActive(true);

   //Date & Time of Decease
   DateTimeType DeceaseTime;
   DeceaseTime=DateTimeType.parseV3("20190213103000");
   p.setDeceased(DeceaseTime);

   //Languages & preferred
   Patient.PatientCommunicationComponent c1;
   CodeableConcept la1;
   la1=new CodeableConcept();
   la1.addCoding().setSystem("urn:ietf:bcp:47").setCode("en-US");
   CodeableConcept la2;
   la2=new CodeableConcept();
   la2.addCoding().setSystem("urn:ietf:bcp:47").setCode("es");
   p.addCommunication().setLanguage(la1).setPreferred(true);
   p.addCommunication().setLanguage(la2).setPreferred(false);

   //Marital Status
   CodeableConcept ms;
   ms=new CodeableConcept();
   ms.addCoding().setSystem("http://terminology.hl7.org/CodeSystem/v3-MaritalStatus").setCode("W");
   p.setMaritalStatus(ms);

   //Birth Date
      DateType i = new DateType();
      i.fromStringValue("1968-07-23");
      p.setBirthDateElement(i);


      // Organization in Charge - Simple reference to an identifier/display, not url
      Reference ref;
      ref=new Reference();
      Identifier ide;
      ide=new Identifier();
      ide.setSystem("http://npi.org/identifiers");
      ide.setValue("999999");
      ref.setDisplay("Ann Arbor General Hospital");
      ref.setIdentifier(ide);
      p.setManagingOrganization(ref);
      //Photo
      Attachment pho;

      pho=new Attachment();
      //String to Byte
      String s="iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAC0lEQVR4nGNgAAIAAAUAAXpeqz8=";
      byte[] b =s.getBytes(Charset.forName("UTF-8"));
      pho.setData(b);
      pho.setContentType("image/png");
      p.addPhoto(pho);

   String res2;
   res2 = ctx.newXmlParser().setPrettyPrint(true).encodeResourceToString(p);

   System.out.println(res2);

   MethodOutcome outcome = client.create()
         .resource(p)
         .conditionalByUrl("Patient?identifier=http://hospital.gov/patients%7C9999999")
        .execute();

      // We will populate the observation now
      Observation obs;
      obs = new Observation();
      // The local id of the patient resource will be the reference for our observation.subject
      // We will also retrieve the display from the patient resource
      IIdType id;
      id=outcome.getId();
      Reference r = new Reference();
      String display=p.getName().get(0).getFamily().toString()+" , "+p.getName().get(0).getGivenAsSingleString();
      r.setDisplay(display);
      r.setReference(id.getResourceType()+"/"+ id.getIdPart());
      obs.setSubject(r);
      // The time the observation was issued
      InstantType IssuedTime;
      IssuedTime=InstantType.parseV3("20190101103000+0300");
      obs.setIssuedElement(IssuedTime);
      // The value for the glucose
      Quantity q = new Quantity();
      q.setValue(6.3).setUnit("mmol/L").setCode("mmol/L").setSystem("http://unitsofmeasure.org");
      obs.setValue(q);
      //Lab Code (Serum Glucose) - LOINC
      CodeableConcept lc;
      lc=new CodeableConcept();
      lc.addCoding().setSystem("http://loinc.org").setCode("14771-0");
      obs.setCode(lc);

      //Now we create the observation in the server
      MethodOutcome outcomeResult = client.create()
         .resource(obs)
         .execute();
      if (outcomeResult.getCreated())
      {
         System.out.println(("Observation Resource Created ")+outcomeResult.getId());
       }
   }

}
