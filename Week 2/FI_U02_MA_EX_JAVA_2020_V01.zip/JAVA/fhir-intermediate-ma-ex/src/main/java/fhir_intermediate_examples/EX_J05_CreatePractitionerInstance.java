package fhir_intermediate_examples;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.rest.api.MethodOutcome;
import ca.uhn.fhir.rest.client.api.IGenericClient;
import org.hl7.fhir.r4.model.*;
import org.hl7.fhir.instance.model.api.IIdType;

public class EX_J05_CreatePractitionerInstance
{

   public static void main(String[] args) {
      // Create a context
      FhirContext ctx = FhirContext.forR4();

      // Create a client
      IGenericClient client = ctx.newRestfulGenericClient("http://fhir.hl7fundamentals.org/r4");

      // Step 1 - Create the instance and populate it

      Practitioner newDoctor;

      {
         newDoctor = new Practitioner();
         //active Record
         newDoctor.setActive(true);
         //Name (family, given)
         newDoctor.addName()
            .setFamily("Dellacroix")
            .addGiven("Madeleine");
         //Identifier
         newDoctor.addIdentifier()
            .setSystem("http://canada.gov/cpn")
            .setValue("51922");
         //Full Address
         newDoctor.addAddress()
            .addLine("3766 Papineau Avenue")
            .setCity("Montreal")
            .setState("Quebec")
            .setPostalCode("H2K 4J5")
            .setCountry("Canada");
         // Phone & e-Mail
         newDoctor.addTelecom()
            .setSystem(ContactPoint.ContactPointSystem.PHONE)
            .setValue("613-555-0192");
         newDoctor.addTelecom()
            .setSystem(ContactPoint.ContactPointSystem.EMAIL)
            .setValue("qcpamxms9dq@groupbuff.com");
         // Specialty
         CodeableConcept q;
         Coding t;
         {
            t = new Coding();
            t.setCode("OB/GYN");
            t.setSystem("http://canada.gov/cpnq");
            q = new CodeableConcept();
            q.addCoding(t);

            newDoctor.addQualification()
               .setCode(q);
         }

      }
      // Step 2 - Invoke the server create method
      MethodOutcome outcome = client.create()
         .resource(newDoctor)
         .execute();

      // Step 3 - Obtain the Server's assigned id if the operation was successful
      if (outcome.getCreated()) {
         IIdType id = outcome.getId();
         {
            System.out.println("Created practitioner, got ID: " + id);
         }
      }
      else
      {
         System.out.println("Error "+outcome.getOperationOutcome().toString() );

      }
   }

}
