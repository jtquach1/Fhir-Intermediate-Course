package fhir_intermediate_examples;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.narrative.DefaultThymeleafNarrativeGenerator;
import ca.uhn.fhir.narrative.INarrativeGenerator;
import ca.uhn.fhir.rest.api.MethodOutcome;
import ca.uhn.fhir.rest.client.api.IGenericClient;
import org.hl7.fhir.instance.model.api.IIdType;
import org.hl7.fhir.r4.model.*;
import org.hl7.fhir.utilities.xhtml.NodeType;
import org.hl7.fhir.utilities.xhtml.XhtmlComposer;
import org.hl7.fhir.utilities.xhtml.XhtmlNode;

import java.nio.charset.Charset;
import java.sql.Date;
import java.util.List;
import java.util.UUID;

public class EX_J31_CreateIPSDocument {

      public static void main(String[] args) {
         // Create a context
         FhirContext ctx = FhirContext.forR4();
         // Automatic creation of narrative text elements for all resources with templates
         INarrativeGenerator narrativeGen = new DefaultThymeleafNarrativeGenerator();
         ctx.setNarrativeGenerator(narrativeGen);

         // Create a client
         IGenericClient client = ctx.newRestfulGenericClient("http://fhir.hl7fundamentals.org/r4");

      /*
      Minimum Resources for an IPS are:
      Composition (1st Entry)
      +Patient
      +Organization
      +Author
      +MedicationStatement
      +Condition
      +AllergyIntolerance

       */
         // We set up full Entry Ids for all the resources
         // They will serve as references between the resources inside the bundle

         String CompositionEntryId=String.valueOf(UUID.randomUUID());
         String OrganizationEntryId=String.valueOf(UUID.randomUUID());
         String PatientEntryId=String.valueOf(UUID.randomUUID());
         String AuthorEntryId=String.valueOf(UUID.randomUUID());
         String MedicationStatementEntryId=String.valueOf(UUID.randomUUID());
         String ConditionEntryId = String.valueOf(UUID.randomUUID());
         String AllergyIntoleranceMedicationEntryId= String.valueOf(UUID.randomUUID());
         String AllergyIntoleranceFoodEntryId= String.valueOf(UUID.randomUUID());

         //We populate the organization
         //IPS Must-Support: identifier, name, telecom, address
         Organization org = new Organization();
         org.addIdentifier().setSystem("http://npi.org/identifiers")
            .setValue("7777777");
         org.setName("New York General Clinic");
         Address aOrg=new Address();
         aOrg.addLine("1234 Org Street").setCity("New York").setCountry("US").setState("NY").setPostalCode("90210");
         org.addAddress(aOrg);
         //Telecom / Phone
         org.addTelecom().setSystem(ContactPoint.ContactPointSystem.PHONE).setValue("(555) 888-7777");
         org.setMeta(new Meta().addProfile("http://hl7.org/fhir/uv/ips/StructureDefinition/Organization-uv-ips"));

         // Setup a Reference to this Organization
         Reference OrganizationRef;
         OrganizationRef=new Reference();
         OrganizationRef.setDisplay(org.getName());
         OrganizationRef.setReference("Organization/"+OrganizationEntryId);


         //We populate the author
         Practitioner pra = new Practitioner();
         //Full Name
         pra.addName().addGiven("Practitio").setFamily("Thomas").
            addPrefix("Mr.").setUse(HumanName.NameUse.OFFICIAL);
         //Identifier
         pra.addIdentifier(new Identifier().setSystem("http://physicians-id.gov/physicians").setValue("8888888").setUse(Identifier.IdentifierUse.OFFICIAL));
         //Address
         Address aPra=new Address();
         aPra.addLine("4321 Med Street").setCity("New York").setCountry("US").setState("NY").setPostalCode("90210");
         pra.addAddress(aPra);
         //Phone
         pra.addTelecom().setSystem(ContactPoint.ContactPointSystem.PHONE).setValue("(555) 666-6777");
         //E-Mail Address
         pra.addTelecom().setSystem(ContactPoint.ContactPointSystem.EMAIL).setValue("practitio@everymail.com");
         pra.setMeta(new Meta().addProfile("http://hl7.org/fhir/uv/ips/StructureDefinition/Practitioner-uv-ips"));

         //Setup a reference to this practitioner
         Reference AuthorRef=new Reference();
         AuthorRef.setDisplay(pra.getNameFirstRep().getNameAsSingleString());
         AuthorRef.setReference("Practitioner/"+AuthorEntryId);

         //We populate the patient
         //IPS Must-Support: name (family/given), telecom, gender, birthDate, address (line/city/state/postalCode
         // /country) , contact (relationship,name, telecom, address, organization - ref , communication ,
         // generalPractitioner
         Patient p;
         p=new Patient();
         //Full Name
         p.addName().addGiven("Adama").setFamily("Alvarado").
            addSuffix("II").addPrefix("Ms.").setUse(HumanName.NameUse.OFFICIAL);
         //Identifier
         p.addIdentifier(new Identifier().setSystem("http://citizens-id.gov/citizens").setValue("123456").setUse(Identifier.IdentifierUse.OFFICIAL));
         //We will use this identifier to search for the patient We won't add it if it exists
         //Address
         Address a=new Address();
         a.addLine("1234 Elm Street").setCity("New York").setCountry("US").setState("NY").setPostalCode("90210");
         p.addAddress(a);
         //Phone
         p.addTelecom().setSystem(ContactPoint.ContactPointSystem.PHONE).setValue("(555) 777-9999");
         //E-Mail Address
         p.addTelecom().setSystem(ContactPoint.ContactPointSystem.EMAIL).setValue("alvarado@everymail.com");
         //Gender
         p.setGender(Enumerations.AdministrativeGender.MALE);
         //Active
         p.setActive(true);
         //Birth Date
         DateType i = new DateType();
         i.fromStringValue("1978-06-20");
         p.setBirthDateElement(i);
         p.addGeneralPractitioner(AuthorRef);

         p.setManagingOrganization(OrganizationRef);
         p.setMeta(new Meta().addProfile("http://hl7.org/fhir/uv/ips/StructureDefinition/Patient-uv-ips"));


         Reference PatientRef=new Reference();
         PatientRef.setDisplay(p.getNameFirstRep().getNameAsSingleString())
            .setReference("Patient/"+PatientEntryId);

      /*

      Create the composition resource
      Composition resource mandatory elements for IPS are
      identifier, status, type
      author, title, confidentiality
      attester, custodian
      Mandatory sections for IPS: Problems, Medications, Allergies
       */
         Composition cmp=new Composition();
         //Document Unique Identifier issued by myhospital
         String DocumentId=String.valueOf(UUID.randomUUID());
         cmp.setIdentifier(new Identifier().setSystem("http://myhospital.org.uk").setValue(DocumentId));
         //Document Status: Final
         cmp.setStatus(Composition.CompositionStatus.FINAL);
         //Document Type: IPS
         CodeableConcept lcd;
         lcd=new CodeableConcept();
         lcd.addCoding().setSystem("http://loinc.org").setCode("60591-5").setDisplay("Patient Summary Document");
         cmp.setType(lcd);
         // Subject for the Document: Reference to the Patient Entry
         cmp.setSubject(PatientRef);
         // The date/time the Component was Created
         DateTimeType CreationTime=DateTimeType.now();
         cmp.setDateElement(CreationTime);
         // Author
         cmp.addAuthor().setReference("Practitioner/"+AuthorEntryId);
         // Confidentiality : Normal
         cmp.setConfidentiality(Composition.DocumentConfidentiality.N);
         // Title
         cmp.setTitle("Patient Summary For "+p.getNameFirstRep().getNameAsSingleString());
         // Attester
         cmp.addAttester().setMode(Composition.CompositionAttestationMode.LEGAL)
            .setParty(OrganizationRef);
         cmp.setMeta(new Meta().addProfile("http://hl7.org/fhir/uv/ips/StructureDefinition/Composition-uv-ips"));

         // Custodian
         cmp.setCustodian(OrganizationRef);
         // Sections

         // Allergies

         Narrative almenarrative=new Narrative();
         almenarrative.setStatusAsString("generated");
         almenarrative.setDivAsString("ALLERGY - MEDICATION - CRITICALITY -HIGH -PENICILLIN");

         // Section Entries: Allergy to Penicillin
         AllergyIntolerance peni = new AllergyIntolerance();
         peni
            .setType(AllergyIntolerance.AllergyIntoleranceType.ALLERGY)
            .addCategory(AllergyIntolerance.AllergyIntoleranceCategory.MEDICATION)
            .setCriticality(AllergyIntolerance.AllergyIntoleranceCriticality.HIGH)
            .setPatient(PatientRef)
            .setCode(new CodeableConcept().addCoding(new Coding().setCode("373270004").setSystem("http://snomed.info/sct").setDisplay("Substance with penicillin structure and antibacterial mechanism of action (substance)")))
            .setText(almenarrative)
            .setMeta(new Meta().addProfile("http://hl7.org/fhir/uv/ips/StructureDefinition/AllergyIntolerance-uv-ips"));

         Reference peniRef=new Reference();
         peniRef.setReference("AllergyIntolerance/"+AllergyIntoleranceMedicationEntryId);

         //                  No known food allergies
         Narrative alfonarrative=new Narrative();
         alfonarrative.setStatusAsString("generated");
         alfonarrative.setDivAsString("No Known Food Allergies");

         AllergyIntolerance nofo= new AllergyIntolerance();
         nofo
            .setType(AllergyIntolerance.AllergyIntoleranceType.ALLERGY)
            .addCategory(AllergyIntolerance.AllergyIntoleranceCategory.FOOD)
            .setPatient(PatientRef)
            .setCode(new CodeableConcept().addCoding(new Coding().setCode("no-known-food-allergies").setSystem("http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips").setDisplay("No Known Food Allergies")))
            .setText(alfonarrative)
            .setMeta(new Meta().addProfile("http://hl7.org/fhir/uv/ips/StructureDefinition/AllergyIntolerance-uv-ips"));

         Reference nofoRef=new Reference();
         nofoRef.setReference("AllergyIntolerance/"+AllergyIntoleranceFoodEntryId);

         Narrative alernarrative=new Narrative();
         alernarrative.setStatusAsString("generated");
         alernarrative.setDivAsString("Food: Not Known Medication: Allergy to penicillin");

         cmp.addSection().setCode(CCB("http://loinc.org","48765-2","Allergies and Intolerance Document"))
            .setTitle("Allergies and Intolerances")
            .setText(alernarrative)
            .addEntry(peniRef)
            .addEntry(nofoRef);

         //Problems
 /*
      Must-Support by IPS for Condition
      clinicalStatus
      verificationStatus
      category
      severity
      code
      subject
      onsetDateTime
      asserter
      */
         Condition cond=new Condition();
         cond.setClinicalStatus(CCB("http://terminology.hl7.org/CodeSystem/condition-clinical","active","Active"));
         cond.setVerificationStatus(CCB("http://terminology.hl7.org/CodeSystem/condition-ver-status","confirmed","Confirmed"));
         cond.addCategory(CCB("http://loinc.org","75326-9","Problem"));
         cond.setSeverity(CCB("http://loinc.org","LA6751-7","Moderate"));
         cond.setCode(CCB("http://snomed.info/sct","54329005","Acute myocardial infarction of anterior wall"));
         cond.setOnset(new DateTimeType().setValue(Date.valueOf("2019-01-01")));
         cond.setSubject(PatientRef);
         cond.setAsserter(AuthorRef);
         Narrative condnarrative = new Narrative();
         condnarrative.setStatusAsString("generated");
         condnarrative.setDivAsString("Acute myocardial infarction of anterior wall, 01-Jan-2019, Active, Confirmed");
         cond.setText(condnarrative);
         cond.setMeta(new Meta().addProfile("http://hl7.org/fhir/uv/ips/StructureDefinition/Condition-uv-ips"));

         Reference condRef=new Reference();
         condRef.setReference("Condition/"+ConditionEntryId);


         cmp.addSection().setCode(CCB("http://loinc.org","11450-4","Problems"))
            .setTitle("Active Problems")
            .setText(cond.getText())
            .addEntry(condRef);
         // MedicationStatement

         MedicationStatement medi=new MedicationStatement();

         Reference mediRef=new Reference();
         mediRef.setReference("MedicationStatement/"+MedicationStatementEntryId);

         medi.setStatus(MedicationStatement.MedicationStatementStatus.ACTIVE);
         medi.setMedication(CCB("http://snomed.info/sct","108979001","Clopidogrel"));
         medi.setSubject(PatientRef);
         medi.setInformationSource(AuthorRef);
         medi.addReasonReference(condRef);
         Dosage dose=new Dosage();
         dose.setText("75 mg orally once a day");
         dose.setRoute(CCB(" http://standardterms.edqm.eu","20053000","Oral"));
         Timing timi=new Timing();
         timi.setCode(CCB("http://terminology.hl7.org/CodeSystem/v3-GTSAbbreviation","QD","Daily"));
         dose.setTiming(timi);
         medi.addDosage(dose);
         Narrative medinarrative=new Narrative();
         medinarrative.setStatusAsString("generated");
         medinarrative.setDivAsString("Clopidogrel, 75mg Orally, once a day");
         medi.setText(medinarrative);
         medi.setMeta(new Meta().addProfile("http://hl7.org/fhir/uv/ips/StructureDefinition/MedicationStatement-uv-ips"));

         cmp.addSection().setCode(CCB("http://loinc.org","10160-9","Medications"))
            .setTitle("Medication")
            .setText(medi.getText())
            .addEntry(mediRef);


         Bundle bt =new Bundle();
         {
            //Bundles for Documents are of DOCUMENT type
            bt.setType(Bundle.BundleType.DOCUMENT);
            bt.setId(String.valueOf(UUID.randomUUID()));
            //Composition
            bt.addEntry().setFullUrl(CompositionEntryId)
               .setResource(cmp);
            bt.addEntry().setFullUrl(PatientEntryId)
               .setResource(p);
            bt.addEntry().setFullUrl(OrganizationEntryId)
               .setResource(org);
            bt.addEntry().setFullUrl(AuthorEntryId)
               .setResource(pra);
            bt.addEntry().setFullUrl(ConditionEntryId)
               .setResource(cond);
            bt.addEntry().setFullUrl(MedicationStatementEntryId)
               .setResource(medi);
            bt.addEntry().setFullUrl(AllergyIntoleranceMedicationEntryId)
               .setResource(peni);
            bt.addEntry().setFullUrl(AllergyIntoleranceFoodEntryId)
               .setResource(nofo);
            //Now we post the document to the server
            IIdType id=  client.create().resource(bt).execute().getId();

            // Print the response
            System.out.println(id.toString());

         }
      }

      public static CodeableConcept CCB(String system,String code,String display)
      {
         CodeableConcept ccb=new CodeableConcept();
         ccb.addCoding().setCode(code).setDisplay(display).setSystem(system);
         return ccb;
      }
   }


