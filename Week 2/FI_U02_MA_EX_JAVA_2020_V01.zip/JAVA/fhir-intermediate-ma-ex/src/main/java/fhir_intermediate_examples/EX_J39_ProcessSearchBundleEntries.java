package fhir_intermediate_examples;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.parser.IParser;
import ca.uhn.fhir.rest.api.CacheControlDirective;
import ca.uhn.fhir.rest.client.api.IGenericClient;
import ca.uhn.fhir.util.BundleUtil;
import org.hl7.fhir.instance.model.api.IBaseBundle;
import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.Organization;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r5.model.Observation;

import java.util.ArrayList;
import java.util.List;

public class EX_J39_ProcessSearchBundleEntries {

   public static void main(String[] args) {
      // Create a context
      FhirContext ctx = FhirContext.forR4();

      // Create a client
      IGenericClient client = ctx.newRestfulGenericClient("http://fhir.hl7fundamentals.org/r4");
      /* The easiest way is to include the URL in the search*/
      IParser parser = ctx.newJsonParser();
      //A.1 Search Patients By Name using byURL
      String searchString = "Patient?name=Smith";


// We'll do a search for all Patients and extract the first page Bundle bundle = client
      Bundle results = client
         .search()
         .forResource(Patient.class)
         .and(Patient.BIRTHDATE.beforeOrEquals().day("2019-01-01"))
         .and(Patient.BIRTHDATE.afterOrEquals().day("1968-05-02"))
         .returnBundle(Bundle.class)
         .cacheControl(new CacheControlDirective().setMaxResults(30))
         .count(5)
         .execute();

      List<IBaseResource> patients = new ArrayList<>();
      patients.addAll(BundleUtil.toListOfResources(ctx, results));

      while (results.getLink(IBaseBundle.LINK_NEXT) != null) {
         results = client
            .loadPage()
            .next(results)

            .execute();

         patients.addAll(BundleUtil.toListOfResources(ctx, results));

      }

      for (int i=0;i<patients.size();i++) {

            Patient patient = (Patient) patients.get(i);
            String content=
                           "Name:"+patient.getNameFirstRep().getNameAsSingleString()+
                           " Iden:"+patient.getIdentifierFirstRep().getValue();
         System.out.println(i);
         System.out.println(content);


         Bundle resultsBundle = client
            .search()
            .forResource(Organization.class)
            .and(Organization.ADDRESS_STATE.matchesExactly().value("MI"))
            .and(Organization.ADDRESS_CITY.matchesExactly().value("Ann Arbor"))
            .returnBundle(Bundle.class)
            .execute();

      //resultsBundle will hold your result bundle
         List<IBaseResource> organizations = new ArrayList<>();
         //We store all resources in an array
         organizations.addAll(BundleUtil.toListOfResources(ctx, resultsBundle));
         //Now we process the array
         for (int iOrg=0;iOrg<organizations.size();iOrg++) {

            Organization org = (Organization) organizations.get(iOrg);
            String contents=
               "Name:"+org.getName()+
                  " Iden:"+org.getIdentifierFirstRep().getValue();
            System.out.println(iOrg);
            System.out.println(contents);
         }
         }


         }
      }

