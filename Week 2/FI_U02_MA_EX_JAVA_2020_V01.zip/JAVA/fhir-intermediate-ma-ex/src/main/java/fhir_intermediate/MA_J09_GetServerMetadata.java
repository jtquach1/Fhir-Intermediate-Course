package fhir_intermediate;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.rest.client.api.IGenericClient;
import com.sun.glass.ui.View;
import org.hl7.fhir.r4.model.CapabilityStatement;

public class MA_J09_GetServerMetadata {

   /**
    * This is the solution for Micro Assignment #J.09 - Metadata
    */
   public static void main(String[] args) throws InterruptedException {

      // Create a context
      FhirContext ctx = FhirContext.forR4();

      // Create a client
      IGenericClient client = ctx.newRestfulGenericClient("http://fhir.hl7fundamentals.org/r4");

      /* Direct Read for a Server capabilities for each resource class */
      CapabilityStatement MyConf=client.capabilities()
         .ofType(CapabilityStatement.class).execute();

      // Print the output
      String string = ctx.newXmlParser().setPrettyPrint(true).encodeResourceToString(MyConf);
      System.out.println(string);


   }

}
