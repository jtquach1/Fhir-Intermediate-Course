package fhir_intermediate;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.rest.api.MethodOutcome;
import ca.uhn.fhir.rest.client.api.IGenericClient;
import org.hl7.fhir.instance.model.api.IIdType;
import org.hl7.fhir.r4.model.*;

public class MA_J06_UpdatePatient {
   /**
    * This is the solution for Micro Assignment #J.06 - Update
    */
   public static void main(String[] args) {

      // Create a context
      FhirContext ctx = FhirContext.forR4();

      // Create a client
      IGenericClient client = ctx.newRestfulGenericClient("http://fhir.hl7fundamentals.org/r4");

      /* Direct Read for a Patient resource */
      Patient patient = client.read().resource(Patient.class).withId("49293").execute();

      // Print the output
      String string = ctx.newXmlParser().setPrettyPrint(true).encodeResourceToString(patient);
      System.out.println("Resource Just Read, With Id");
      System.out.println(string);

      //Updating the resource
      //Full Address
      Address ad;
         ad= new Address();
         ad.addLine("3600 Papineau Avenue")
            .setCity("Montreal")
            .setState("Quebec")
            .setPostalCode("H2K 4J5")
            .setCountry("Canada");
      boolean b = (patient.hasAddress());
      if (!b) {patient.addAddress(ad);}
      ContactPoint t = new ContactPoint();
      t.setSystem(ContactPoint.ContactPointSystem.PHONE)
         .setValue("613-555-5555");
      b=(patient.hasTelecom());
      if (!b) patient.addTelecom();

      // Step 2 - Invoke the server update method
      MethodOutcome outcome = client.update()
         .resource(patient)
         .execute();

      // Step 3 - Obtain the Server's version
         String version = outcome.getId().getVersionIdPart();
         {
            System.out.println("Updated patient, got version: " + version);
         }
         /* Direct Read for the Patient resource */
         patient = client.read().resource(Patient.class).withId("49293").execute();

         // Print the output
         string = ctx.newXmlParser().setPrettyPrint(true).encodeResourceToString(patient);
         System.out.println("Resource After Update, With Id/Version");
         System.out.println(string);


}
}
