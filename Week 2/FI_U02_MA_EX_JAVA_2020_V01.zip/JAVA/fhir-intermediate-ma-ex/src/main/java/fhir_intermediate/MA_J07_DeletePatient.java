package fhir_intermediate;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.rest.client.api.IGenericClient;
import org.hl7.fhir.instance.model.api.IBaseOperationOutcome;
import ca.uhn.fhir.model.primitive.IdDt;


public class MA_J07_DeletePatient {
   /**
    * This is the solution for Micro Assignment #J.07 -Delete
    */
   public static void main(String[] args) {

      // Create a context
      FhirContext ctx = FhirContext.forR4();

      // Create a client
      IGenericClient client = ctx.newRestfulGenericClient("http://fhir.hl7fundamentals.org/r4");

      IBaseOperationOutcome resp = client.delete().resourceById(new IdDt("Patient", "73411")).execute();

      // outcome may be null if the server didn't return one
      if (resp != null) {

         System.out.println(resp.toString());
      }


   }
}
