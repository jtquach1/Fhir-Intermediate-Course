package fhir_intermediate;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.rest.client.api.IGenericClient;
import org.hl7.fhir.r4.model.*;

import java.util.Date;

public class MA_J16_CreateAllergyIntolerance

   {


      /**
       * This is the solution for Micro Assignment #J.16 - Populate AllergyIntollerance
       */
      public static void main(String[] args) {
      // Create a context
      FhirContext ctx = FhirContext.forR4();

      // Create a client
      IGenericClient client = ctx.newRestfulGenericClient("http://fhir.hl7fundamentals.org/r4");

      //ClinicalStatus: active
      //type: allergy
      //category: food
      //criticality: high
      //patient: Patient/49293
      //code: 91935009 (http://hl7.org/fhir/ValueSet/substance-code): Allergy to Peanuts
      //onSet: 10 years old (Age)
      AllergyIntolerance newAllergy;

      newAllergy = new AllergyIntolerance()
                .setType(AllergyIntolerance.AllergyIntoleranceType.ALLERGY)
                .addCategory(AllergyIntolerance.AllergyIntoleranceCategory.FOOD)
                .setCriticality(AllergyIntolerance.AllergyIntoleranceCriticality.HIGH)
                .setPatient(new Reference().setReference("Patient/49293"))
                .setOnset(new Age().setCode("y").setValue(10))
                .setCode(new CodeableConcept().addCoding(new Coding().setCode("91935009").setSystem("http://hl7.org/fhir/ValueSet/substance-code").setDisplay("Peanuts")));

         String res = ctx.newXmlParser().setPrettyPrint(true).encodeResourceToString(newAllergy);
         System.out.println(res);

      }
   }


