package fhir_intermediate;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.rest.client.api.IGenericClient;

public class MA_J01_Skeleton
{

   /**
    * This is the solution for the MicroAssignment #J.01 - Just a skeleton
    */
   public static void main(String[] args) {

      // Create a context
      FhirContext ctx = FhirContext.forR4();

      // Create a client
      IGenericClient client = ctx.newRestfulGenericClient("http://fhir.hl7fundamentals.org/r4");
      String string="I am just a skeleton so I do nothing";
      System.out.println(string);

   }

}

