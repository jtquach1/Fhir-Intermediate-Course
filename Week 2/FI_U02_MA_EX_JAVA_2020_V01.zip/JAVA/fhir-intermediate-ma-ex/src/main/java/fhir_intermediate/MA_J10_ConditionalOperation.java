package fhir_intermediate;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.rest.api.MethodOutcome;
import ca.uhn.fhir.rest.client.api.IGenericClient;
import com.sun.codemodel.internal.JCatchBlock;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.DateType;
import org.hl7.fhir.r4.model.Enumerations;
import org.hl7.fhir.instance.model.api.IIdType;

public class MA_J10_ConditionalOperation
{

   /**
    * This is the solution for Micro Assignment #J.10 - Create New Patient Conditionally
    */
   public static void main(String[] args) {
      // Create a context
      FhirContext ctx = FhirContext.forR4();

      // Create a client
      IGenericClient client = ctx.newRestfulGenericClient("http://fhir.hl7fundamentals.org/r4");

      // Step 1 - Create the instance and populate it

      Patient newPatient;

      {
         newPatient = new Patient();
         //Name (family, given)
         newPatient.setActive(true);
         newPatient.addName()
            .setFamily("Test Patient Family")
            .addGiven("Test Patient Given");
         //Identifier
         newPatient.addIdentifier()
            .setSystem("http://central.patient.id/ident")
            .setValue("99999999");
         newPatient.setGender(Enumerations.AdministrativeGender.MALE);
         newPatient.setBirthDateElement(new DateType("1968-05-01"));

      }
      // Step 2 Option a- Invoke the server create conditional method (url)
      try{

         MethodOutcome outcome = client.create()
            .resource(newPatient)
            .conditionalByUrl("Patient?identifier=http://central.patient.id/ident%7C99999999")
            .execute();
         if (outcome.getCreated() != null)
         {
            IIdType id = outcome.getId();
            {
               System.out.println("Created patient, got ID: " + id);
            }
         } else

         {
            System.out.println("The patient already exists:" + outcome.getId());

         }

      }
      catch(Exception ex)
      {
         System.out.println("Error Creating the Resource:" + ex.toString());


      }
   }

}
