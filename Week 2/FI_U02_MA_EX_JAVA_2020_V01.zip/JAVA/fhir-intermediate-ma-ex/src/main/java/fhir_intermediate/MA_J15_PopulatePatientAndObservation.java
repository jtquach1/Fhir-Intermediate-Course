package fhir_intermediate;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.rest.api.MethodOutcome;
import ca.uhn.fhir.rest.client.api.IGenericClient;
import com.sun.tools.javac.jvm.Code;
import org.hl7.fhir.r4.model.*;
import org.hl7.fhir.instance.model.api.IIdType;

import java.nio.charset.Charset;
import java.util.Date;

public class MA_J15_PopulatePatientAndObservation {
   /**
    * This is the solution for Micro Assignment #J.15 -Populate Patient and Observation
    * Relate both using simple reference
    */

   /* This class populates a Patient resource, creates the resource in the server
      if it is not there already, and then relates the resource to a new observation
      and creates the observation
      Name:
      [use] Official [Prefix] Mr. [Given] Adam [Family] Alvarado, [Suffix] II
      Photo: data (base64): iVBORw0KGgoBBBBNSUhEUgBBBBEBBBBBCAYBBBBfFcSJBBBBC0lEQVR4nGNgBBIBBBUBBXpeqz8=
      Identifiers
      [system] http://nygc.com/patients [value] 1234567 (Medical Record Number)
      [system] http://citizens-id.gov/citizens [value] 59999999-I (National Identifier)
      Address: 1234 Elm Stret, New York, NY (90210), USA
      Phone # : (555) 777-9999
      e-mail Address: alvarado@everymail.com
      Gender: Male
      Active: Yes
      Marital Status: Married
      Born on: May 20, 1978
      Preferred Language: Spanish (Spain). Also speaks English
      Organization in Charge: New York General Clinic (www.nygc.com) – 9999 General Clinic Ave-nue, New York, NY (90210), USA
      Observation: Lab –Serum Creatinine Value: 65 umol/L, March 3, 2020 07:00:00 EST / LOINC Code: 14682-9 (http://loinc.org)

    */
   public static void main(String[] args) {
      // Create a context
      FhirContext ctx = FhirContext.forR4();

      // Create a client
      IGenericClient client = ctx.newRestfulGenericClient("http://fhir.hl7fundamentals.org/r4");

      // Step 1 - Create the instance and populate it

      Patient p;
      p=new Patient();

      //Full Name
      p.addName().addGiven("Adam").setFamily("Alvarado").
         addSuffix("II").addPrefix("Mr.").setUse(HumanName.NameUse.OFFICIAL);

      //Identifiers
      p.addIdentifier(new Identifier().setSystem("http://citizens-id.gov/citizens").setValue("59999999-I").setUse(Identifier.IdentifierUse.OFFICIAL));
      p.addIdentifier(new Identifier().setSystem("http://nygc.com/patients").setValue("9999999").setUse(Identifier.IdentifierUse.SECONDARY));

      //Address
      Address a=new Address();
      a.addLine("1234 Elm Street").setCity("New York").setCountry("US").setState("NY").setPostalCode("90210");
      p.addAddress(a);

      //Phone
      p.addTelecom().setSystem(ContactPoint.ContactPointSystem.PHONE).setValue("(555) 777-9999");

      //E-Mail Address
      p.addTelecom().setSystem(ContactPoint.ContactPointSystem.EMAIL).setValue("alvarado@everymail.com");

      //Gender
      p.setGender(Enumerations.AdministrativeGender.MALE);

      //Active
      p.setActive(true);
      //Languages & preferred
      Patient.PatientCommunicationComponent c1;
      CodeableConcept la1;
      la1=new CodeableConcept();
      la1.addCoding().setSystem("urn:ietf:bcp:47").setCode("en-US");
      CodeableConcept la2;
      la2=new CodeableConcept();
      la2.addCoding().setSystem("urn:ietf:bcp:47").setCode("es-ES");
      p.addCommunication().setLanguage(la1).setPreferred(false);
      p.addCommunication().setLanguage(la2).setPreferred(true);

      //Marital Status
      CodeableConcept ms;
      ms=new CodeableConcept();
      ms.addCoding().setSystem("http://terminology.hl7.org/CodeSystem/v3-MaritalStatus").setCode("M");
      p.setMaritalStatus(ms);

      //Birth Date
      DateType i = new DateType();
      i.fromStringValue("1978-06-20");
      p.setBirthDateElement(i);


      // Organization in Charge - Simple reference to an identifier/display, not url
      Reference ref;
      ref=new Reference();
      Identifier ide;
      ide=new Identifier();
      ide.setSystem("http://npi.org/identifiers");
      ide.setValue("7777777");
      ref.setDisplay("New York General Clinic");
      ref.setIdentifier(ide);
      p.setManagingOrganization(ref);
      //Photo
      Attachment pho;

      pho=new Attachment();
      //String to Byte
      String s="iVBORw0KGgoBBBBNSUhEUgBBBBEBBBBBCAYBBBBfFcSJBBBBC0lEQVR4nGNgBBIBBBUBBXpeqz8=";
      byte[] b =s.getBytes(Charset.forName("UTF-8"));
      pho.setData(b);
      pho.setContentType("image/png");
      p.addPhoto(pho);

      String res2;
      res2 = ctx.newXmlParser().setPrettyPrint(true).encodeResourceToString(p);

      System.out.println(res2);

      MethodOutcome outcome = client.create()
         .resource(p)
         .conditionalByUrl("Patient?identifier=http://nygc.com/patients%7C1234567")
         .execute();

      // We will populate the observation now
      Observation obs;
      obs = new Observation();
      // The local id of the patient resource will be the reference for our observation.subject
      // We will also retrieve the display from the patient resource
      IIdType id;
      id=outcome.getId();
      Reference r = new Reference();
      String display=p.getName().get(0).getFamily().toString()+" , "+p.getName().get(0).getGivenAsSingleString();
      r.setDisplay(display);
      r.setReference(id.getResourceType()+"/"+ id.getIdPart());
      obs.setSubject(r);
      // The time the observation was issued
      InstantType IssuedTime;
      IssuedTime=InstantType.parseV3("20200320070000+0300");
      obs.setIssuedElement(IssuedTime);
      // The value for the creatinine
      Quantity q = new Quantity();
      q.setValue(65.0).setUnit("umol/L").setCode("umol/L").setSystem("http://unitsofmeasure.org");
      obs.setValue(q);
      //Lab Code (Serum Creatinine) - LOINC
      CodeableConcept lc;
      lc=new CodeableConcept();
      lc.addCoding().setSystem("http://loinc.org").setCode("14682-9");
      obs.setCode(lc);

      //Now we create the observation in the server
      MethodOutcome outcomeResult = client.create()
         .resource(obs)
         .execute();
      if (outcomeResult.getCreated())
      {
         System.out.println(("Observation Resource Created ")+outcomeResult.getId());
      }
   }

}
