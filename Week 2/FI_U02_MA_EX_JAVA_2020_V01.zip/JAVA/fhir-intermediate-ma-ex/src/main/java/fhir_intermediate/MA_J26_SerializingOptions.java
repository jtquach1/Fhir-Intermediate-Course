package fhir_intermediate;
import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.rest.client.api.IGenericClient;
import org.hl7.fhir.r4.model.CodeableConcept;
import org.hl7.fhir.r4.model.Coding;
import org.hl7.fhir.r4.model.ContactPoint;
import org.hl7.fhir.r4.model.Practitioner;

public class MA_J26_SerializingOptions {

   /**
    * This is the solution for Mini Assignment #26 - Use Serializing Options
    */
   public static void main(String[] args) {
      // Create a context
      FhirContext ctx = FhirContext.forR4();

      // Create a client
      IGenericClient client = ctx.newRestfulGenericClient("http://fhir.hl7fundamentals.org/r4");

      // Step 1 - Create the instance and populate it

      Practitioner newDoctor;

      {
         newDoctor = new Practitioner();
         //active Record
         newDoctor.setActive(true);
         //Name (family, given)
         newDoctor.addName()
            .setFamily("Dellacroix")
            .addGiven("Madeleine");
         //Identifier
         newDoctor.addIdentifier()
            .setSystem("http://canada.gov/cpn")
            .setValue("51922");
         //Full Address
         newDoctor.addAddress()
            .addLine("3766 Papineau Avenue")
            .setCity("Montreal")
            .setState("Quebec")
            .setPostalCode("H2K 4J5")
            .setCountry("Canada");
         // Phone & e-Mail
         newDoctor.addTelecom()
            .setSystem(ContactPoint.ContactPointSystem.PHONE)
            .setValue("613-555-0192");
         newDoctor.addTelecom()
            .setSystem(ContactPoint.ContactPointSystem.EMAIL)
            .setValue("qcpamxms9dq@groupbuff.com");
         // Specialty
         CodeableConcept q;
         Coding t;
         {
            t = new Coding();
            t.setCode("OB/GYN");
            t.setSystem("http://canada.gov/cpnq");
            q = new CodeableConcept();
            q.addCoding(t);

            newDoctor.addQualification()
               .setCode(q);
         }

      }
      String content=ctx.newJsonParser().setPrettyPrint(true).setSummaryMode(true).setSuppressNarratives(true).encodeResourceToString(newDoctor);

      System.out.println(content);

   }

}
