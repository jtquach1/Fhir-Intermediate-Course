package fhir_intermediate;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.model.primitive.CodeDt;
import ca.uhn.fhir.model.primitive.StringDt;
import ca.uhn.fhir.rest.api.MethodOutcome;
import ca.uhn.fhir.rest.client.api.IGenericClient;
import org.hl7.fhir.instance.model.api.IIdType;
import org.hl7.fhir.r4.model.*;

import java.sql.Date;

public class MA_J18_CreatePatientWithExtensions {


   /**
    * This is the solution for Micro Assignment #J.18 - Create New Patient with Extensions
    */
   public static void main(String[] args) {
      // Create a context
      FhirContext ctx = FhirContext.forR4();

      // Create a client
      IGenericClient client = ctx.newRestfulGenericClient("http://fhir.hl7fundamentals.org/r4");

      // Step 1 - Create the instance and populate it
      // Create the extensions first

      // a. Simple Extension
      // BirthSex
      //   url=http://hl7.org/fhir/us/core/StructureDefinition/us-core-birthsex>
      //   code : "F"

      // b. Complex Extension
      //
      // Ethnicity
      //   url=http://hl7.org/fhir/us/core/StructureDefinition/us-core-ethnicity

      // First Component

      //   url=ombCategory
      //   coding=urn:oid:2.16.840.1.113883.6.238: 2135-2 (Hispanic or Latino)
      //   url=detailed
      //   coding=urn:oid:2.16.840.1.113883.6.238: 2184-0 (Dominican)
      //   url=text
      //   text=Hispanic or Latino
      // Race

      // Simple Extension
         Extension ext1=new Extension("http://hl7.org/fhir/us/core/StructureDefinition/us-core-birthsex"
                                  , new CodeType("F"));

         // Complex Extension - only URL
      Extension extc1=new Extension("http://hl7.org/fhir/us/core/StructureDefinition/us-core-ethnicity");
      // First Component
      extc1.addExtension("ombCategory",
         new CodeableConcept().addCoding().setCode("2135-2").setSystem("urn:oid:2.16.840.1.113883.6.238").setDisplay("Hispanic or Latino"));
      // Second Component
      extc1.addExtension("detailed",
         new CodeableConcept().addCoding().setCode("2184-0").setSystem("urn:oid:2.16.840.1.113883.6.238").setDisplay("Dominican"));
      // Third Component
      extc1.addExtension("text",
         new StringType("Hispanic or Latino"));

      Extension ext3=new Extension("http://hl7.org/fhir/uv/ips/StructureDefinition/abatement-dateTime-uv-ips"
         ,new DateTimeType().setValue(Date.valueOf("2018-02-02")));

      // Second Component
         // Complex Component
      Patient newPatient;

      {
         newPatient = new Patient();
         //Name (family, given)
         newPatient.setActive(true);
         newPatient.addName()
            .setFamily("Test Patient Family")
            .addGiven("Test Patient Given");
         //Identifier
         newPatient.addIdentifier()
            .setSystem("http://testpatient.id/mrn")
            .setValue("99999999");
         newPatient.setGender(Enumerations.AdministrativeGender.MALE);
         newPatient.setBirthDateElement(new DateType("1968-05-01"));
         newPatient.getBirthDateElement().addExtension(
            new Extension("http://hl7.org/fhir/StructureDefinition/patient-birthTime"
               ,new DateTimeType().parseV3("19680501203040")
               ));


      }

      newPatient.addExtension(ext1);
      newPatient.addExtension(extc1);
      newPatient.addExtension(ext3);
      // Step 2 - Invoke the server create method
      MethodOutcome outcome = client.create()
         .resource(newPatient)
         .execute();

      // Step 3 - Obtain the Server's assigned id if the operation was successful
      if (outcome.getCreated()) {
         IIdType id = outcome.getId();
         {
            System.out.println("Created patient, got ID: " + id);
         }
      }
      else
      {
         System.out.println("Error "+outcome.getOperationOutcome().toString() );

      }
   }

}
