package fhir_intermediate;
import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.parser.IParser;
import ca.uhn.fhir.rest.client.api.IGenericClient;
import org.hl7.fhir.r4.model.*;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;


public class MA_J19_ProcessExtensions {



   /**
    * This is the solution for Micro Assignment #J.19 - Process extensions
    */
   public static void main(String[] args) throws IOException {
      // Create a context

      FhirContext ctx = FhirContext.forR4();
      //This part is just Java to get the file name and read the XML file
      System.out.print("Enter the file name for the patient resource in XML : ");

      Scanner scanner = new Scanner(System. in);
      String inputString = scanner. nextLine();
      String content = readFile(inputString, Charset.defaultCharset());

      IParser parser = ctx.newXmlParser();
      Patient pa=parser.parseResource(Patient.class, content);
      String MyExtension="http://hl7.org/fhir/us/core/StructureDefinition/us-core-race";
      if (pa.hasExtension(MyExtension))
      {

         System.out.println("Extension Found!");

         for ( int iExt =0;iExt<pa.getExtension().size();iExt++) {

            Extension ex=pa.getExtension().get(iExt);
            String extUrl=ex.getUrl().toString();

            if (extUrl.equals(MyExtension))

               if (ex.hasExtension())
               {

                  System.out.println("Complex Extension");
                  for (int jExt = 0; jExt < ex.getExtension().size(); jExt++) {

                     Extension iex = ex.getExtension().get(jExt);
                     System.out.println("Extension URL");
                     System.out.println(iex.getUrl().toString());
                     System.out.println("Data Type");
                     System.out.println(iex.getValue().fhirType().toString());
                     System.out.println("Value:");
                     if (iex.hasValue())
                     {

                        if (iex.getValue().fhirType().equals("Coding"))
                        {
                           System.out.print("Coding:");
                           System.out.println(iex.getValue().getNamedProperty("code").getValues().toString());
                        }
                        else
                        {

                           System.out.println(iex.getValue().toString());
                        }

                     }
                  }
               }
            else {
                  System.out.println("Simple Extension");
                  System.out.println("Extension URL");
                  System.out.println(ex.getUrl().toString());
                  System.out.println("Extension Value");
                  System.out.println("Value:");
                  if (ex.getValue().fhirType().equals("Coding")) {

                     System.out.println(ex.getValue().getNamedProperty("code").getValues().toString());
                  }
                  else
                  {
                     System.out.println("No Coding");
                  }
               }

         }

      }
   }



   static String readFile(String path, Charset encoding)
      throws IOException
   {
      File f=null;
      f=new File(path);
      if (f.exists())
      {
         byte[] encoded = Files.readAllBytes(Paths.get( f.getAbsoluteFile().toString()));
         return new String(encoded, encoding);
      }
      else
      {
         return "";
      }
   }
}
