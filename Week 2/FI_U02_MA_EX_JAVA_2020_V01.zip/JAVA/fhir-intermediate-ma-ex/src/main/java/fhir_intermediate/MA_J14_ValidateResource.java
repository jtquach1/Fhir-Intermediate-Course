package fhir_intermediate;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.validation.*;
import org.hl7.fhir.r4.model.OperationOutcome;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class MA_J14_ValidateResource {
   /**
    * This is the solution for Micro Assignment #J.14 - Validate an XML File
    */
   public static void main(String[] args) throws IOException {


      FhirContext ctx = FhirContext.forR4();
      //This part is just Java to get the file name and read the XML file
      System.out.print("Enter the file name for the resource in XML : ");

      Scanner scanner = new Scanner(System. in);
      String inputString = scanner. nextLine();
      String content = readFile(inputString,Charset.defaultCharset());

      //This part is actual resource validation. No need to parse or say which resource class it is!
      FhirValidator val = ctx.newValidator();
      IValidatorModule module1 = new SchemaBaseValidator(ctx);
      val.registerValidatorModule(module1);
      ValidationResult result = val.validateWithResult(content);

      if (result.isSuccessful()) {
         System.out.println("Validation passed");

      } else {
         System.out.println("Validation failed");
      }

      List<SingleValidationMessage> messages = result.getMessages();

      for (
         SingleValidationMessage next : messages) {
         System.out.println("Message:");
         System.out.println(" * Location: " + next.getLocationString());
         System.out.println(" * Severity: " + next.getSeverity());
         System.out.println(" * Message : " + next.getMessage());
      }

      // As an operation resource
      OperationOutcome oo = (OperationOutcome) result.toOperationOutcome();
      String results = ctx.newXmlParser().setPrettyPrint(true).encodeResourceToString(oo);
      System.out.println(results);
   }
   static String readFile(String path, Charset encoding)
      throws IOException
   {
      File f=null;
      f=new File(path);
      if (f.exists())
      {
         byte[] encoded = Files.readAllBytes(Paths.get( f.getAbsoluteFile().toString()));
         return new String(encoded, encoding);
      }
      else
      {
         return "";
      }
   }
}
