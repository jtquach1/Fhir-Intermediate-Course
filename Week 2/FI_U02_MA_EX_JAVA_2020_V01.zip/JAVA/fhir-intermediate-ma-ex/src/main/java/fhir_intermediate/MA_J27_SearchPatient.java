package fhir_intermediate;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.rest.api.CacheControlDirective;
import ca.uhn.fhir.rest.client.api.IGenericClient;
import org.hl7.fhir.r4.model.*;

import java.util.Date;

public class MA_J27_SearchPatient {

   public static void main(String[] args) {
      // Create a context
      FhirContext ctx = FhirContext.forR4();

      // Create a client
      IGenericClient client = ctx.newRestfulGenericClient("http://fhir.hl7fundamentals.org/r4");

      //a. Search By Name,Gender,BirthDate using criterion
      String s="1965-05-05";
      Bundle bu2=client.search()
         .forResource(Patient.class).and(Patient.FAMILY.matches().value("SMITH"))
         .and(Patient.GENDER.exactly().code("male"))
         .and(Patient.BIRTHDATE.afterOrEquals().day(s))
         .returnBundle(Bundle.class)
         .execute();
      //Print the Bundle result
      System.out.println(ctx.newJsonParser().setPrettyPrint(true).encodeResourceToString(bu2));

      //b. Search By Identifier
      Bundle bu3 = client
         .search()
         .forResource((Patient.class))
         .and(Patient.IDENTIFIER.exactly().systemAndCode("http://hospital.gov/patients","9999999"))
         .returnBundle(Bundle.class)
         .execute();
      //Print the Bundle result
      System.out.println("Search for Identifier");
      System.out.println(ctx.newJsonParser().setPrettyPrint(true).encodeResourceToString(bu3));


      //c. Search By Name+Gender using byURL
      String searchString = "Patient?name=John&gender=female";
      Bundle bu1 = client
         .search()
         .byUrl(searchString)
         .returnBundle(Bundle.class)
         .execute();
      System.out.println("Search for name and gender, by url");
      System.out.println(ctx.newJsonParser().setPrettyPrint(true).encodeResourceToString(bu1));


   }
}
