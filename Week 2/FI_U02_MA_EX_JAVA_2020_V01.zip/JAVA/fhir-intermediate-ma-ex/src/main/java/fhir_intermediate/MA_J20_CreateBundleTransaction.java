package fhir_intermediate;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.rest.api.MethodOutcome;
import ca.uhn.fhir.rest.client.api.IGenericClient;
import org.hl7.fhir.r4.model.*;

import java.nio.charset.Charset;
import java.util.UUID;
public class MA_J20_CreateBundleTransaction {

   /**
    * This is the solution for Micro Assignment #J.20 - Create Bundle for Transaction
    */
   public static void main(String[] args) {
      // Create a context
      FhirContext ctx = FhirContext.forR4();

      // Create a client
      IGenericClient client = ctx.newRestfulGenericClient("http://fhir.hl7fundamentals.org/r4");


      //First we will create all the resource instances we need
   //Using temporary identifiers for the resource we want to relate
   //through references inside of the transaction
   //These references will be resolved by the FHIR server
   String PatientEntryId=String.valueOf(UUID.randomUUID());
   String DeviceEntryId=String.valueOf(UUID.randomUUID());
   String DiastolicEntryId=String.valueOf(UUID.randomUUID());
   String SystolicEntryId=String.valueOf(UUID.randomUUID());

   //We populate the patient
   //Very important to remember the patient identifier: we will use it to check if it doesn't exist
   //in the conditional request
   Patient p;
   p=new Patient();

   //Full Name
      p.addName().addGiven("Adama").setFamily("Alvarado").
   addSuffix("II").addPrefix("Ms.").setUse(HumanName.NameUse.OFFICIAL);

   //Identifier
      p.addIdentifier(new Identifier().setSystem("http://citizens-id.gov/citizens").setValue("123456").setUse(Identifier.IdentifierUse.OFFICIAL));
      //We will use this identifier to search for the patient We won't add it if it exists


   //Address
   Address a=new Address();
      a.addLine("1234 Elm Street").setCity("New York").setCountry("US").setState("NY").setPostalCode("90210");
      p.addAddress(a);

   //Phone
      p.addTelecom().setSystem(ContactPoint.ContactPointSystem.PHONE).setValue("(555) 777-9999");

   //E-Mail Address
      p.addTelecom().setSystem(ContactPoint.ContactPointSystem.EMAIL).setValue("alvarado@everymail.com");

   //Gender
      p.setGender(Enumerations.AdministrativeGender.MALE);

   //Active
      p.setActive(true);


   //Birth Date
   DateType i = new DateType();
      i.fromStringValue("1978-06-20");
      p.setBirthDateElement(i);


   // Organization in Charge - Simple reference to an identifier/display, not url
   Reference ref;
   ref=new Reference();
   Identifier ide;
   ide=new Identifier();
      ide.setSystem("http://npi.org/identifiers");
      ide.setValue("7777777");
      ref.setDisplay("New York General Clinic");
      ref.setIdentifier(ide);
      p.setManagingOrganization(ref);

      String PatToken=p.getIdentifierFirstRep().getSystem().toString()+"|"
         +p.getIdentifierFirstRep().getValue().toString();


      Device d=new Device();

      d.addIdentifier().setSystem("http://wwww.americandevices.com").setValue("123456");
      d.addDeviceName().setName("BLOOD PRESSURE MASTER");
      d.addVersion().setValue("1.23.78");
      d.setManufacturer("AMERICAN BLOOD PRESSURE DEVICES");
      d.setModelNumber("2000 PLUS");
      d.setSerialNumber("123456");
      //The patient for the device is the one in the first entry of the transaction
      //See below the first addEntry/FullURL
      d.setPatient(new Reference().setReference("Patient/"+PatientEntryId));

      //First Observation: Diastolic Pressure, Related to the patient and device

      Reference r = new Reference();
      String display=p.getName().get(0).getFamily().toString()+" , "+p.getName().get(0).getGivenAsSingleString();
      r.setDisplay(display);
      r.setReference("Patient/"+PatientEntryId);
      Observation obsS=new Observation();
      obsS.setSubject(r);
      // The time the observation was issued
      InstantType IssuedTime;
      IssuedTime=InstantType.withCurrentTime();
      obsS.setIssuedElement(IssuedTime);
      // The value for the creatinine
      Quantity q = new Quantity();
      q.setValue(120.0).setUnit("mmHG").setCode("mmHG").setSystem("http://unitsofmeasure.org");
      obsS.setValue(q);
      //Systolic BP
      CodeableConcept lc;
      lc=new CodeableConcept();
      lc.addCoding().setSystem("http://loinc.org").setCode("8480-6");
      obsS.setCode(lc);

      //Second Observation: Diastolic Pressure, Related to the patient and device

      Reference rd = new Reference();
      rd.setDisplay(display);
      rd.setReference("Patient/"+PatientEntryId);

      Reference rdev = new Reference();
      String displayDev=d.getDeviceNameFirstRep().getName().toString()
                       +" "+d.getModelNumber().toString()
                       +" "+d.getSerialNumber().toString();


      rdev.setDisplay(displayDev);

      rdev.setReference("Device/"+DeviceEntryId);

      // The time the observation was issued
      IssuedTime=InstantType.withCurrentTime();
      // The value for the diastolic BP
      Quantity qd = new Quantity();
      qd.setValue(80.0).setUnit("mmHG").setCode("mmHG").setSystem("http://unitsofmeasure.org");
      //Diastolic BP
      CodeableConcept lcd;
      lcd=new CodeableConcept();
      lcd.addCoding().setSystem("http://loinc.org").setCode("8462-4");

      Observation obsD=new Observation();
      obsD.setSubject(rd);
      obsD.setDevice(rdev);
      obsD.setIssuedElement(IssuedTime);
      obsD.setValue(qd);
      obsD.setCode(lcd);


      Bundle bt =new Bundle();
   {
      bt.setType(Bundle.BundleType.TRANSACTION);
      bt.setId(String.valueOf(UUID.randomUUID()));
      //Patient
      bt.addEntry().setFullUrl(PatientEntryId)
                   .setResource(p)
                   .setRequest(new Bundle.BundleEntryRequestComponent()
                     .setMethod(Bundle.HTTPVerb.PUT)
                     .setUrl("Patient?identifier=" +PatToken)
                      );
      String devToken=d.getIdentifierFirstRep().getSystem().toString()+"|"
                     +d.getIdentifierFirstRep().getValue().toString();
      //Device
      bt.addEntry().setFullUrl(DeviceEntryId)
         .setResource(d)
         .setRequest(new Bundle.BundleEntryRequestComponent()
            .setMethod(Bundle.HTTPVerb.PUT)
            .setUrl("Device?identifier=" +devToken)
         );

      //Observation 1: Systolic
      bt.addEntry().setFullUrl(SystolicEntryId)
      .setResource(obsS)
      .setRequest(new Bundle.BundleEntryRequestComponent()
         .setMethod(Bundle.HTTPVerb.POST)
         .setUrl("Observation")
      );

      //Observation 2: Diastolic
      bt.addEntry().setFullUrl(DiastolicEntryId)
      .setResource(obsD)
      .setRequest(new Bundle.BundleEntryRequestComponent()
         .setMethod(Bundle.HTTPVerb.POST)
         .setUrl("Observation")
      );
      //Now we post the transaction to the server
      Bundle outcomeResult = client.transaction()
         .withBundle(bt)
         .execute();

      // Print the response
      System.out.println(ctx.newXmlParser().setPrettyPrint(true).encodeResourceToString(outcomeResult));

   }
}
}
