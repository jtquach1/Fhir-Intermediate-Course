package fhir_intermediate;
import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.parser.IParser;
import ca.uhn.fhir.rest.client.api.IGenericClient;
import org.hl7.fhir.r4.model.*;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;

public class MA_J25_ValidateAgainstProfileOperation {

   /**
    * This is the solution for Micro Assignment #J.25 - Validate Resource Against Profile
    */
   public static void main(String[] args) throws IOException {

      FhirContext ctx = FhirContext.forR4();
      IGenericClient client = ctx.newRestfulGenericClient("http://fhir.hl7fundamentals.org/r4/");

// The hapi context object is used to create a new XML parser
// instance. The parser can then be used to parse (or unmarshall) the
// string message into a Patient object
      System.out.print("Enter the file name for the resource in XML : ");

      Scanner scanner = new Scanner(System. in);
      String inputString = scanner. nextLine();
      String content = readFile(inputString, Charset.defaultCharset());
      IParser parser = ctx.newXmlParser();
      Patient patient=parser.parseResource(Patient.class, content);

      Parameters inParams = new Parameters();
      {
         inParams.addParameter().setName("resource").setResource(patient);
      }


      Parameters outParams = client
         .operation()
         .onType(Patient.class)
         .named("$validate")
         .withParameters(inParams)
         .execute();

      OperationOutcome oo = (OperationOutcome) outParams.getParameter().get(0).getResource();
      String results = ctx.newXmlParser().setPrettyPrint(true).encodeResourceToString(oo);
      System.out.println(results);




   }
   static String readFile(String path, Charset encoding)
      throws IOException
   {
      File f=null;
      f=new File(path);
      if (f.exists())
      {
         byte[] encoded = Files.readAllBytes(Paths.get( f.getAbsoluteFile().toString()));
         return new String(encoded, encoding);
      }
      else
      {
         return "";
      }
   }
}
