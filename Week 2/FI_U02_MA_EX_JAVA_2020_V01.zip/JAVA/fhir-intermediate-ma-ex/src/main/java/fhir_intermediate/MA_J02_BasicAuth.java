package fhir_intermediate;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.rest.client.api.IClientInterceptor;
import ca.uhn.fhir.rest.client.interceptor.BasicAuthInterceptor;
import ca.uhn.fhir.rest.client.api.IGenericClient;
import org.hl7.fhir.r4.model.Patient;

public class MA_J02_BasicAuth
{

   /**
    * This is the solution for Micro Assignment #J.02 - Basic Auth
    */
   public static void main(String[] args) {

      // Create a context
      FhirContext ctx = FhirContext.forR4();

      // Create an HTTP basic auth interceptor
      String username = "your_user_name";
      String password = "your_password";
      // Create a client
      IGenericClient client = ctx.newRestfulGenericClient("http://fhir.hl7fundamentals.org/r4");
      // Register the interceptor
      IClientInterceptor authInterceptor = new BasicAuthInterceptor(username, password);
      client.registerInterceptor(authInterceptor);

      // Read a Patient
      Patient patient = client.read().resource(Patient.class).withId("49293").execute();

      // Print the output
      String string = ctx.newXmlParser().setPrettyPrint(true).encodeResourceToString(patient);
      System.out.println(string);

   }

}
