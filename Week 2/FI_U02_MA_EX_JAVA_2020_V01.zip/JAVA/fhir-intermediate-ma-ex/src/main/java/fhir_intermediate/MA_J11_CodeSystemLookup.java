package fhir_intermediate;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.rest.client.api.IGenericClient;
import org.hl7.fhir.r4.model.CodeSystem;
import org.hl7.fhir.r4.model.CodeType;
import org.hl7.fhir.r4.model.Parameters;
import org.hl7.fhir.r4.model.UriType;

public class MA_J11_CodeSystemLookup {
   /**
    * This is the solution for Micro Assignment #J.11 - Terminology Lookup -> CodeSystem
    */
   public static void main(String[] args) {

      FhirContext ctx = FhirContext.forR4();

      IGenericClient client = ctx.newRestfulGenericClient("https://snowstorm-alpha.ihtsdotools.org/fhir/");
      try {

         Parameters outParams = client
            .operation()
            .onType(CodeSystem.class)
            .named("lookup")
            .withParameter(Parameters.class, "code", new CodeType("73211009"))
            .andParameter("system", new UriType("http://snomed.info/sct"))
            .execute();

         String displayTitle = outParams.getParameter().get(0).getName().toString();
         String displayValue = outParams.getParameter().get(0).getValue().primitiveValue();
         System.out.println(displayTitle+":"+displayValue);

      }
      catch (Exception e)
      {
         System.out.println("Error:" +e.getMessage());

      }





   }

}
