package fhir_intermediate;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.parser.IParser;
import org.hl7.fhir.r4.model.*;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;

public class MA_J23_ProcessBundleEntries {
   /**
    * This is the solution for Micro Assignment #J.23 - Process bundle entries
    */
   public static void main(String[] args) throws IOException {
      // Create a context

   FhirContext ctx = FhirContext.forR4();
   //This part is just Java to get the file name and read the JSON file
      System.out.print("Enter the file name for the bundle in JSON : ");

   Scanner scanner = new Scanner(System. in);
   String inputString = scanner. nextLine();
   String content = readFile(inputString, Charset.defaultCharset());

      IParser parser = ctx.newJsonParser();
   Bundle bu=parser.parseResource(Bundle.class,content);
   String PatientName="";
   String PatientIden="";
   String ConditionCode="";

         for (Bundle.BundleEntryComponent entry: bu.getEntry()) {
            System.out.println(entry.getFullUrl());
            System.out.println(entry.getResource().fhirType());
            if (entry.getResource().fhirType().toString()=="Patient")
            {
               Patient pa=(Patient) entry.getResource();
               PatientName=pa.getNameFirstRep().getNameAsSingleString();
               PatientIden=pa.getIdentifierFirstRep().getValue();

            }
            if(entry.getResource().fhirType().toString()=="Condition")
            {
               Condition co=(Condition) entry.getResource();
               ConditionCode=co.getCode().getCodingFirstRep().getCode();

            }
         }
      System.out.println("Name:"+PatientName);
      System.out.println("Iden:"+PatientIden);
      System.out.println("Condition:"+ConditionCode);

   }
   static String readFile(String path, Charset encoding)
      throws IOException
   {
      File f=null;
      f=new File(path);
      if (f.exists())
      {
         byte[] encoded = Files.readAllBytes(Paths.get( f.getAbsoluteFile().toString()));
         return new String(encoded, encoding);
      }
      else
      {
         return "";
      }
   }


}

