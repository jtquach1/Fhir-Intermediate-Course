package fhir_intermediate;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.rest.api.MethodOutcome;
import ca.uhn.fhir.rest.client.api.IGenericClient;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.DateType;
import org.hl7.fhir.r4.model.Enumerations;
import org.hl7.fhir.instance.model.api.IIdType;

public class MA_J05_CreateNewPatient
{

   /**
    * This is the solution for Micro Assignment #J.05 - Create New Patient
    */
   public static void main(String[] args) {
   // Create a context
   FhirContext ctx = FhirContext.forR4();

   // Create a client
   IGenericClient client = ctx.newRestfulGenericClient("http://fhir.hl7fundamentals.org/r4");

   // Step 1 - Create the instance and populate it

      Patient newPatient;

   {
      newPatient = new Patient();
      //Name (family, given)
      newPatient.setActive(true);
      newPatient.addName()
      .setFamily("Test Patient Family")
      .addGiven("Test Patient Given");
      //Identifier
      newPatient.addIdentifier()
      .setSystem("http://testpatient.id/mrn")
      .setValue("99999999");
      newPatient.setGender(Enumerations.AdministrativeGender.MALE);
      newPatient.setBirthDateElement(new DateType("1968-05-01"));

   }
   // Step 2 - Invoke the server create method
   MethodOutcome outcome = client.create()
      .resource(newPatient)
      .execute();

   // Step 3 - Obtain the Server's assigned id if the operation was successful
      if (outcome.getCreated()) {
         IIdType id = outcome.getId();
         {
            System.out.println("Created patient, got ID: " + id);
         }
      }
      else
      {
         System.out.println("Error "+outcome.getOperationOutcome().toString() );

      }
   }

}
