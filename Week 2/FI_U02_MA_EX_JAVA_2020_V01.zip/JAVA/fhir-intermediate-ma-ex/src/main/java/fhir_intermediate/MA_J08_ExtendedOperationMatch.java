package fhir_intermediate;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.model.primitive.IdDt;
import ca.uhn.fhir.parser.IParser;
import ca.uhn.fhir.rest.client.api.IGenericClient;
import org.hl7.fhir.r4.model.*;

public class MA_J08_ExtendedOperationMatch {


   /**
    * This is the solution for Micro Assignment #J.08 - Extended Operations
    */
   public static void main(String[] args) {

      FhirContext ctx = FhirContext.forR4();
      IGenericClient client = ctx.newRestfulGenericClient("https://testapp.hospitalitaliano.org.ar/masterfile-federacion-service/fhir");

      String msgString = "\t{\n" +
         "\t\t\t\t\t\"resourceType\": \"Patient\",\n" +
         "\t\t\t\t\t\"identifier\": [\n" +
         "\t\t\t\t\t  {\n" +
         "\t\t\t\t\t      \"use\": \"usual\",\n" +
         "\t\t\t\t\t      \"system\": \"http://www.renaper.gob.ar/dni\",\n" +
         "\t\t\t\t\t      \"value\": \"23327755\"\n" +
         "\t\t\t\t\t  }\n" +
         "\t\t\t\t\t],\n" +
         "\t\t\t\t\t\"name\": [\n" +
         "\t\t\t\t\t    {\n" +
         "\t\t\t\t\t        \"_family\": {\n" +
         "\t\t\t\t\t            \"extension\": [\n" +
         "\t\t\t\t\t                {\n" +
         "\t\t\t\t\t                    \"url\": \"http://hl7.org/fhir/StructureDefinition/humanname-fathers-family\",\n" +
         "\t\t\t\t\t                    \"valueString\": \"Martinez\"\n" +
         "\t\t\t\t\t                }\n" +
         "\t\t\t\t\t            ]\n" +
         "\t\t\t\t\t        },\n" +
         "\t\t\t\t\t        \"given\": [\n" +
         "\t\t\t\t\t    \t\t\"Julian\"\n" +
         "\t\t\t\t\t        ]\n" +
         "\t\t\t\t\t    }\n" +
         "\t\t\t\t\t],\n" +
         "\t\t\t\t\t\"birthDate\": \"1973-06-12\",\n" +
         "\t\t\t\t\t\"gender\": \"male\"\n" +
         "\t\t\t\t}\n";

// The hapi context object is used to create a new XML parser
// instance. The parser can then be used to parse (or unmarshall) the
// string message into a Patient object
      IParser parser = ctx.newJsonParser();
      Patient patient=parser.parseResource(Patient.class, msgString);
      int cnt=5;
      Parameters inParams = new Parameters();
      {
         inParams.addParameter().setName("resource").setResource(patient);
         inParams.addParameter().setName("count").setValue(new IntegerType(5));
      }

      // Invoke $everything on "Patient/1"

      Parameters outParams = client
         .operation()
         .onType(Patient.class)
         .named("$match")
         .withParameters(inParams)
         .execute();
      /*
       * Note that the $everything operation returns a Bundle instead
       * of a Parameters resource. The client operation methods return a
       * Parameters instance however, so HAPI creates a Parameters object
       * with a single parameter containing the value.
       */
      Bundle responseBundle = (Bundle) outParams.getParameter().get(0).getResource();

      // Print the response bundle

      String MyString = ctx.newXmlParser().setPrettyPrint(true).encodeResourceToString(responseBundle);
      System.out.println(MyString);



   }

}
