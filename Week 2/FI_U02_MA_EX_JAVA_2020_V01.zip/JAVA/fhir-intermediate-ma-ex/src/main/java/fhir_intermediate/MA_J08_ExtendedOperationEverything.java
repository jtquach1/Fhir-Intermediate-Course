package fhir_intermediate;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.model.primitive.DateDt;
import ca.uhn.fhir.model.primitive.IdDt;
import ca.uhn.fhir.rest.client.api.IGenericClient;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.DateType;
import org.hl7.fhir.r4.model.Parameters;


public class MA_J08_ExtendedOperationEverything {

   /**
    * This is the solution for Micro Assignment #J.08 - Extended Operations
    */
   public static void main(String[] args) {

   FhirContext ctx = FhirContext.forR4();
   IGenericClient client = ctx.newRestfulGenericClient("http://fhir.hl7fundamentals.org/r4");


   // Create the input parameters to pass to the server
   org.hl7.fhir.r4.model.DateType dtBeg = new DateType("2019-11-01");
   org.hl7.fhir.r4.model.DateType dtEnd = new DateType("2020-02-02");


   Parameters inParams = new Parameters();
   {

      inParams.addParameter().setName("start").setValue(dtBeg);
      inParams.addParameter().setName("end").setValue(dtEnd);
   }

   // Invoke $everything on "Patient/1"

   Parameters outParams = client
       .operation()
      .onInstance(new IdDt("Patient", "73412"))
      .named("$everything")
      .withParameters(inParams)
      .execute();
      /*
       * Note that the $everything operation returns a Bundle instead
       * of a Parameters resource. The client operation methods return a
       * Parameters instance however, so HAPI creates a Parameters object
       * with a single parameter containing the value.
       */
      Bundle responseBundle = (Bundle) outParams.getParameter().get(0).getResource();

      // Print the response bundle

      String MyString = ctx.newXmlParser().setPrettyPrint(true).encodeResourceToString(responseBundle);
      System.out.println(MyString);



   }
}



