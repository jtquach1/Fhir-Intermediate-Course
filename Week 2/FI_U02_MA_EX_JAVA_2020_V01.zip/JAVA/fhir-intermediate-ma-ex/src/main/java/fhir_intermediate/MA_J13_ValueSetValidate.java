package fhir_intermediate;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.model.primitive.IdDt;
import ca.uhn.fhir.rest.client.api.IClientInterceptor;
import ca.uhn.fhir.rest.client.api.IGenericClient;
import ca.uhn.fhir.rest.client.interceptor.BasicAuthInterceptor;
import org.hl7.fhir.dstu3.model.*;

public class MA_J13_ValueSetValidate {

      /**
       * This is the solution for Micro Assignment #J.13 - Terminology validate-code-> ValueSet
       */
      public static void main(String[] args) {

         FhirContext ctx = FhirContext.forDstu3();
         // LOINC requires Basic user auth
         String username = "kaminkerdiego"; // Your LOINC user Name
         String password = "superloinc2019."; // Your LOINC password
         // Register the interceptor
         IClientInterceptor authInterceptor = new BasicAuthInterceptor(username, password);
         IGenericClient client = ctx.newRestfulGenericClient("https://fhir.loinc.org");
         client.registerInterceptor(authInterceptor);

         try {

            Parameters outParams = client
               .operation()
               .onInstance(new IdDt("ValueSet","LG33055-1"))
               .named("validate-code")
               .withParameter(Parameters.class, "system", new UriType("http://loinc.org"))
               .andParameter("code",new StringType("8867-4"))
               .execute();

            String result = outParams.getParameter().get(0).getValue().toString();
            String message= outParams.getParameter().get(1).getValue().toString();
            String display=outParams.getParameter().get(2).getValue().toString();
            System.out.println(result+":"+message+":"+display);

         }
         catch (Exception e)
         {
            System.out.println("Error:" +e.getMessage());

         }

      }



}
