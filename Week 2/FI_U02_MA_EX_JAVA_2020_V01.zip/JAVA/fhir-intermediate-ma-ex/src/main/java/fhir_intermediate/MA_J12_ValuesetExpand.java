package fhir_intermediate;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.rest.client.api.IGenericClient;
import org.hl7.fhir.r4.model.*;

public class MA_J12_ValuesetExpand {

   /**
    * This is the solution for Micro Assignment #J.12a/b - Terminology Expand -> ValueSet
    */
   public static void main(String[] args) {

      FhirContext ctx = FhirContext.forR4();

      IGenericClient client = ctx.newRestfulGenericClient("https://snowstorm-fhir.snomedtools.org/fhir/");
      try {

         Parameters outParams = client
            .operation()
            .onType(ValueSet.class)
            .named("expand")
            .withParameter(Parameters.class, "url", new UriType("http://snomed.info/sct?fhir_vs=ecl/^450970008"))
            .andParameter("filter",new StringType("pain"))
            .execute();
            // For assignment 12.a
            //.withParameter(Parameters.class, "url", new UriType("http://snomed.info/sct?fhir_vs=isa/73211009"))
            //For assignment 12.b
            // change url to ?fhir_vs=ecl/^450970008
            // and add   .andParameter("filter",new StringType("pain"))

         ValueSet v = (ValueSet)outParams.getParameter().get(0).getResource();
         ValueSet.ValueSetExpansionComponent
            ve=v.getExpansion();
         for (int i = 0; i < ve.getTotal(); i++)
         {
           ValueSet.ValueSetExpansionContainsComponent
              ci=ve.getContains().get(i);
              String code=ci.getCode();
              String display=ci.getDisplay();
            System.out.println(code+":"+display);
         }

         }
      catch (Exception e)
      {
         System.out.println("Error:" +e.getMessage());

      }

   }



   }
