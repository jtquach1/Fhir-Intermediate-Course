package fhir_intermediate;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.parser.IParser;
import org.hl7.fhir.r4.model.*;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;

public class MA_J24_ParsePatient {
   /**
    * This is the solution for Micro Assignment #J.24 - Parse Patient Resource from XML File.
    * Print the patient name and identifier
    */
   public static void main(String[] args) throws IOException {
      // Create a context

      FhirContext ctx = FhirContext.forR4();
      //This part is just Java to get the file name and read the XML file
      System.out.print("Enter the file name for the patient in XML : ");

      Scanner scanner = new Scanner(System. in);
      String inputString = scanner. nextLine();
      String content = readFile(inputString, Charset.defaultCharset());

      IParser parser = ctx.newXmlParser();
      Patient pa=parser.parseResource(Patient.class,content);
      String  PatientName=pa.getNameFirstRep().getNameAsSingleString();
      String  PatientIden=pa.getIdentifierFirstRep().getValue();
      System.out.println("Name:"+PatientName);
      System.out.println("Iden:"+PatientIden);

   }
   static String readFile(String path, Charset encoding)
      throws IOException
   {
      File f=null;
      f=new File(path);
      if (f.exists())
      {
         byte[] encoded = Files.readAllBytes(Paths.get( f.getAbsoluteFile().toString()));
         return new String(encoded, encoding);
      }
      else
      {
         return "";
      }
   }


}

