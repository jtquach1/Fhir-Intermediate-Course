package fhir_intermediate;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.rest.client.api.IGenericClient;
import org.hl7.fhir.r4.model.*;

import java.util.Date;

public class MA_J22_IncludeContainedResource {

   /**
    * This is the solution for Micro Assignment #J.22 - Include contained Practitioner resource as Asserter
    * of an AllergyIntolerance resource
    */
   public static void main(String[] args) {
      // Create a context
      FhirContext ctx = FhirContext.forR4();

      // Create a client
      IGenericClient client = ctx.newRestfulGenericClient("http://fhir.hl7fundamentals.org/r4");

      //ClinicalStatus: active
      //type: allergy
      //category: food
      //criticality: high
      //patient: Patient/49293
      //code: 91935009 (http://hl7.org/fhir/ValueSet/substance-code): Allergy to Peanuts
      //onSet: 10 years old (Age)
      //We populate the asserter

      Practitioner pra = new Practitioner();
      //Full Name
      pra.addName().addGiven("Contained").setFamily("Billy").
         addPrefix("Mr.").setUse(HumanName.NameUse.OFFICIAL);
      //Identifier
      pra.addIdentifier(new Identifier().setSystem("http://physicians-id.gov/physicians").setValue("3333333").setUse(Identifier.IdentifierUse.OFFICIAL));
      //Address
      Address aPra=new Address();
      aPra.addLine("7890 Cont Street").setCity("New York").setCountry("US").setState("NY").setPostalCode("90210");
      pra.addAddress(aPra);
      //Phone
      pra.addTelecom().setSystem(ContactPoint.ContactPointSystem.PHONE).setValue("(555) 111-2222");
      //E-Mail Address
      pra.addTelecom().setSystem(ContactPoint.ContactPointSystem.EMAIL).setValue("contained@everymail.com");
      pra.setId("#Practitioner_Asserter");
      AllergyIntolerance newAllergy;

      newAllergy = new AllergyIntolerance()
         .setType(AllergyIntolerance.AllergyIntoleranceType.ALLERGY)
         .addCategory(AllergyIntolerance.AllergyIntoleranceCategory.FOOD)
         .setCriticality(AllergyIntolerance.AllergyIntoleranceCriticality.HIGH)
         .setPatient(new Reference().setReference("Patient/49293"))
         .setOnset(new Age().setCode("y").setValue(10))
         .setCode(new CodeableConcept().addCoding(new Coding().setCode("91935009").setSystem("http://hl7.org/fhir/ValueSet/substance-code").setDisplay("Peanuts")));

      newAllergy.getContained().add(pra);
      newAllergy.setAsserter(new Reference().setReference("#Practitioner_Asserter"));

      String res = ctx.newXmlParser().setPrettyPrint(true).encodeResourceToString(newAllergy);
      System.out.println(res);

   }
}
