package fhir_intermediate;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.parser.IParser;
import ca.uhn.fhir.rest.client.api.IGenericClient;
import org.hl7.fhir.r4.model.*;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;

public class MA_J17_ExtractInformationFromObservation {

   /**
    * This is the solution for Micro Assignment #J.17 - Extract information from OBSERVATION.XML resource
    */
   public static void main(String[] args) throws IOException {
      FhirContext ctx = FhirContext.forR4();
      //This part is just Java to get the file name and read the XML file
      System.out.print("Enter the file name for the resource in XML : ");

      Scanner scanner = new Scanner(System. in);
      String inputString = scanner. nextLine();
      String content = readFile(inputString, Charset.defaultCharset());

      IParser parser = ctx.newXmlParser();
      Observation ob=parser.parseResource(Observation.class, content);
      // text – status – category – code – date/time - value
      String catCode="";
      String catSystem="";
      String statusCode="";
      String obsCode="";
      String obsSystem="";
      String obsDate="";
      String obsValue="";
      if (ob.hasStatus())
      {
         // Status Code
         statusCode=ob.getStatus().toCode();
         // Category
         catSystem=ob.getCategory().get(0).getCoding().get(0).getSystem();
         catCode  =ob.getCategory().get(0).getCoding().get(0).getCode();
         // Code
         obsSystem=ob.getCode().getCoding().get(0).getSystem();
         obsCode  =ob.getCode().getCoding().get(0).getCode();
         // Date- Time
         obsDate = ob.getEffectiveDateTimeType().getAsV3();
         // Value
         if (ob.hasValueCodeableConcept())
         {
            obsValue=ob.getValueCodeableConcept().getCodingFirstRep().getCode();
         };
         //Narrative
         String sText= ob.getText().getDiv().toString();
         System.out.println("OBSERVATION");
         System.out.println("**Category Code**");
         System.out.println("Code:");
         System.out.println(catCode);
         System.out.println("System:");
         System.out.println("**Observation Code**");
         System.out.println("Code:");
         System.out.println(obsCode);
         System.out.println("System:");
         System.out.println(obsSystem);
         System.out.println("**Value**");
         System.out.println(obsValue);
         System.out.println("**Date/Time**");
         System.out.println(obsDate);
         System.out.println("**Status Code**");
         System.out.println(statusCode);
         System.out.println("**Text**");
         System.out.println(sText);

      }

   }
   static String readFile(String path, Charset encoding)
      throws IOException
   {
      File f=null;
      f=new File(path);
      if (f.exists())
      {
         byte[] encoded = Files.readAllBytes(Paths.get( f.getAbsoluteFile().toString()));
         return new String(encoded, encoding);
      }
      else
      {
         return "";
      }
   }

}
