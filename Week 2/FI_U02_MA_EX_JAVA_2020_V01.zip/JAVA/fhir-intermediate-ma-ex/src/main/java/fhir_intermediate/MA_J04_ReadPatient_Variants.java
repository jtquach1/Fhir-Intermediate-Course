package fhir_intermediate;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.rest.client.api.IGenericClient;
import org.hl7.fhir.r4.model.Patient;

public class MA_J04_ReadPatient_Variants {

   /**
    * This is the solution for Micro Assignment #J.04 - Read / VRead / url Read
    */
   public static void main(String[] args) {

      // Create a context
      FhirContext ctx = FhirContext.forR4();

      // Create a client
      IGenericClient client = ctx.newRestfulGenericClient("http://fhir.hl7fundamentals.org/r4");

      /* Variant 1 - Direct Read for a Patient resource */
      Patient patient = client.read().resource(Patient.class).withId("49293").execute();

      // Print the output
      String string = ctx.newXmlParser().setPrettyPrint(true).encodeResourceToString(patient);
      System.out.println("With Id");
      System.out.println(string);

      /* Variant 2 - Version Read for a Patient resource */
      Patient patient2 = client.read().resource(Patient.class).withIdAndVersion("49293","1").execute();
      // Print the output
      string = ctx.newXmlParser().setPrettyPrint(true).encodeResourceToString(patient2);
      System.out.println("With Specific Version");
      System.out.println(string);

      // Variant 3 - URL Read for a resource in other server (overrides client url, same context)
      String url="http://test.fhir.org/r4/Patient/example";
      Patient patient3=client.read().resource(Patient.class).withUrl(url).execute();
      string = ctx.newXmlParser().setPrettyPrint(true).encodeResourceToString(patient3);

      System.out.println("With URL");
      System.out.println(string);
   }

}
