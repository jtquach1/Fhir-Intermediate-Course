
      const Client = require('fhir-kit-client');
      
      module.exports={CreateUSCoreR4LabObservation};
      
      async function CreateUSCoreR4LabObservation(server,IdentifierSystem,IdentifierValue
        ,ObservationStatusCode,ObservationDateTime,ObservationLOINCCode,ObservationLOINCDisplay,ResultType,
        NumericResultValue,NumericResultUCUMUnit,CodedResultSNOMEDCode,CodedResultSNOMEDDisplay)
        {

            var aux=""; 
            return aux; 
         
        };
        