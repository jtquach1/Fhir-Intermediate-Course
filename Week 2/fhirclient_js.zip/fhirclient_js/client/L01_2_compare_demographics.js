const Client = require('fhir-kit-client');
module.exports={GetDemographicComparison};


async function GetDemographicComparison(server,patientidentifiersystem,patientidentifiervalue
    ,myFamily,myGiven,myGender,myBirthDate
    )
    {
       var aux=""; 
        return aux;

    }
    