
      const Client = require('fhir-kit-client');
      
      module.exports={CreateUSCoreR4Immunization};
      
      async function CreateUSCoreR4Immunization(server,IdentifierSystem,IdentifierValue,
         ImmunizationStatusCode,
         ImmunizationDateTime,
         ProductCVXCode,
         ProductCVXDisplay,
         ReasonCode)
        {

            var aux=""; 
            return aux; 
         
        };
        