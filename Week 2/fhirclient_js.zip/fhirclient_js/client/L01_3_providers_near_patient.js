const Client = require('fhir-kit-client');
module.exports={GetProvidersNearCity};


async function GetProvidersNearCity(server,patientidentifiersystem,patientidentifiervalue
    )
    {
       var aux=""; 
        
    
        return aux;
    
    }

