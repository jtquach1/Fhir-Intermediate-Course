const Client = require('fhir-kit-client');
module.exports={GetImmunizations};

async function GetImmunizations(server,patientidentifiersystem,patientidentifiervalue
    )
    {
       var aux=""; 
       return aux; 
    }    

    
