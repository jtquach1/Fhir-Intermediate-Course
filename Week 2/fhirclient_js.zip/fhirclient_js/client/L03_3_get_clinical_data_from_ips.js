const Client = require('fhir-kit-client');
module.exports={GetIPSMedications,GetIPSImmunizations};

async function GetIPSMedications(server,patientidentifiersystem,patientidentifiervalue
    )
    {
       var aux=""; 
       return aux; 
    }    
async function GetIPSImmunizations(server,patientidentifiersystem,patientidentifiervalue
   )
   {
      var aux=""; 
      return aux; 
   }    
    