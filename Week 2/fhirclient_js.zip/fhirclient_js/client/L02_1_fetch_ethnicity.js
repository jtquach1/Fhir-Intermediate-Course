const Client = require('fhir-kit-client');
module.exports={GetEthnicity};


async function GetEthnicity(server,patientidentifiersystem,patientidentifiervalue
    )
    {
       var aux=""; 
       return aux; 
    }    


