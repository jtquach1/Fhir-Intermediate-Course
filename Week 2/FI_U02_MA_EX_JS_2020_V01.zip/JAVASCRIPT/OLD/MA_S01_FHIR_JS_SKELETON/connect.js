
function Connect()
{
const fhirClient = new Client({
  baseUrl: 'http://fhir.hl7fundamentals.org/r4'
  });
    alert("I do nothing. I am just a skeleton!");
}

 
 