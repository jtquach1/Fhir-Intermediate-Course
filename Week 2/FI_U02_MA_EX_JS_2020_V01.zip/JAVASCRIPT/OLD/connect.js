
function Connect(){

  alert("Hello");
};   
 