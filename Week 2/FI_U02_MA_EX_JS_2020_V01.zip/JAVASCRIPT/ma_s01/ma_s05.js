const Client  = require('fhir-kit-client')
// This MicroAssignment creates a Patient instance
// Smith, Alan, born 06 May 1965, male, mrn: http://testpatient.id/mrn / 99999999
    const fhirClient = new Client({
    baseUrl: 'http://fhir.hl7fundamentals.org/r4',
    customHeaders:{
        "Content-Type":"application/fhir+json",
        "Accept":"application/fhir+json"
        }
       
    }
);

const newPatient = {
        "resourceType": "Patient",
        "identifier": [
          {
            "system": "http://testpatient.id/mrn/",
            "value": "99999999"
          }
        ],
        "name": [
          {
            "family": "Smith",
            "given": [
              "Alan"
            ]
          }
        ],
        "birthDate":"1968-05-06",
        "gender": "male"
      }
      ;  

  fhirClient.create({
    resourceType: 'Patient',
    body: newPatient,
  }).then((data) => { 
        var NewId=data.id;
        console.log("Id:"+NewId);})
    .catch((error) => { 
        var errorText=JSON.stringify(error);
        console.log(errorText) 
    });

