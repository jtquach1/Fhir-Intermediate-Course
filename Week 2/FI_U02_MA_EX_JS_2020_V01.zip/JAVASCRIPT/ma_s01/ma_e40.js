/*
This example implements searches for three use cases in Argonaut PD Guide
   A.Search for Practitioner by demographics
      A.1.Name
      A.2.Specialty
   B. Search for Practitioner within a region (city, state)
      B.1 Show me practitioners near me
      B.2 Show me every one of this specialty in the city
   C. Search for Practitioner by organizational relationships
      C.1 Practitioner in a specific health organization (e.g. Baptist Health Organization)
Practitioner in a specific clinic (e.g. West Clinic)
 */

const Client = require('fhir-kit-client');
const CapabilityTool = require('fhir-kit-client/lib/capability-tool');
const fhirClient = new Client({
    baseUrl: 'http://fhir.hl7fundamentals.org/r4',
    customHeaders: {
        "Content-Type": "application/fhir+json",
        "Accept": "application/fhir+json"
    }

});

//change the selected option to do the specific search
//A1: Name 
//A2: Specialty
//B1: Practitioners near me
//B2: Everyone in this specialty in this city
//C:  Practitioner search by identifier

var option = 'C';
var resourceClass = "";
var searchCriteria = [];
const MaxPerPage = '10';
switch (option) {
    case "A1":
        resourceClass = "Practitioner";
        searchCriteria = { _count: MaxPerPage, name: 'Smith' }
        break;
    case "A2":
        resourceClass = "PractitionerRole";
        searchCriteria = { _count: MaxPerPage, specialty: "http://snomed.info/sct|408443003" }
        break;
    case "B1":
        //No server still supports this, but it's a great idea
        resourceClass = "PractitionerRole";
        searchCriteria = {
            _count: MaxPerPage,
            "specialty": 'http://snomed.info/sct|408443003',
            "location.near": '-72.519854,42.373222',
            "location.near-distance": '10km'
        }
        break;
    case "B2":
        resourceClass = "PractitionerRole";
        searchCriteria = {
            _count: MaxPerPage,
            "specialty": 'http://snomed.info/sct|408443003',
            "organization.address-city": 'Oklahoma',
            "organization.address-state": 'Oklahoma'
        }
        break;
    case "C":
        searchCriteria = { _count: MaxPerPage, identifier: "http://hl7.org/fhir/sid/us-npi|97860456" }
        break;
    default:
        break;
};

fhirClient
    .search({ resourceType: resourceClass, searchParams: searchCriteria })
    .then((response) => {
        console.log(response);
        return response;
    })
    .then((response) => {
        console.log(response);
        return fhirClient.nextPage(response);
    })
    .then((response) => {
        console.log(response);
        return fhirClient.prevPage(response);
    })
    .catch((error) => {
        console.error(error);
    });