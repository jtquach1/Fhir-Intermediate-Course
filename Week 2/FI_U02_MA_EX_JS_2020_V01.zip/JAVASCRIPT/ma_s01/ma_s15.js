const Client = require('fhir-kit-client')
const fhirClient = new Client({
    baseUrl: 'http://fhir.hl7fundamentals.org/r4',
    customHeaders: {
        "Content-Type": "application/fhir+json",
        "Accept": "application/fhir+json"
    }

});


var p = new Object;

p.resourceType = 'Patient';

/*
Identifiers
[system] http://nygc.com/patients [value] 1234567 (Medical Record Number)
[system] http://citizens-id.gov/citizens [value] 59999999-I (National Identifier)
*/
p.identifier = [{
        use: "official",
        system: "http://citizens-id.gov/citizens",
        value: "59999999-I"
    },
    {
        system: "http://nygc.com/patients",
        value: "1234567"
    }
];

//Active: Yes

p.active = false;
//Name:[use] Official [Prefix] Mr. [Given] Adam [Family] Alvarado, [Suffix] II 

p.name = [{
    use: "official",
    family: "Alvarado",
    given: [
        "Adam"
    ],
    prefix: [
        "Mr."
    ],
    suffix: [
        "II"
    ]
}];
/*Phone # : (555) 777-9999
e-mail Address: alvarado@everymail.com*/

p.telecom = [{
        system: "phone",
        value: "(555) 777-9999"
    },
    {
        system: "email",
        value: "alvarado@everymail.com"
    }
];
//Gender: Male
p.gender = "female";
//Born on: May 20, 1978
p.birthDate = "1978-05-20";
//Address: 1234 Elm Street, New York, NY (90210), USA
p.address = [{
    line: [
        "1234 Elm Street"
    ],
    city: "New York",
    state: "NY",
    postalCode: "90210",
    country: "USA"
}];

//Marital Status: Married

p.maritalStatus = {
    coding: [{
        system: "http://terminology.hl7.org/CodeSystem/v3-MaritalStatus",
        code: "M"
    }]
};
//Photo: data (base64): iVBORw0KGgoBBBBNSUhEUgBBBBEBBBBBCAYBBBBfFcSJBBBBC0lEQVR4nGNgBBIBBBUBBXpeqz8=
p.photo = [{
    contentType: "application/jpeg",
    data: "iVBORw0KGgoBBBBNSUhEUgBBBBEBBBBBCAYBBBBfFcSJBBBBC0lEQVR4nGNgBBIBBBUBBXpeqz8="
}];
//Preferred Language: Spanish (Spain). Also speaks English
p.communication = [{
        language: {
            coding: [{
                system: "urn:ietf:bcp:47",
                code: "es-SP"
            }]
        },
        preferred: true
    },
    {
        language: {
            coding: [{
                system: "urn:ietf:bcp:47",
                code: "en-US"
            }]
        },
        preferred: false
    }
];
//Organization in Charge: New York General Clinic (www.nygc.com) – 9999 General Clinic Avenue, New York, NY (90210), USA NPI-ID (http://npi.org/identifiers): 7777777
p.managingOrganization = {
    identifier: {
        system: "http://npi.org/identifiers",
        value: "7777777"
    },
    display: "New York General Clinic"
}
var DivNarrative =
    "<div xmlns='http://www.w3.org/1999/xhtml'>" +
    "Name:" + p.name[0].family + "," + p.name[0].given[0] + "<br/>" +
    "Identifier:" + p.identifier[0].system + "-" + p.identifier[0].value + "<br/>" +
    "Gender:" + p.gender + "<br/>" +
    "BirthDate:" + p.birthDate + "<br/>" +
    "Active:" + p.active + "<br/>" +
    "Managing Org:" + p.managingOrganization.display + "<br/>" +
    "Address:" + p.address[0].line[0] + " " +
    p.address[0].state + " " +
    p.address[0].city + " (" +
    p.address[0].postalCode + ") " +
    p.address[0].country +
    "<br/>" +
    "Telecom:" + p.telecom[0].System + "-" + p.telecom[0].Value + "<br/>" +
    "</div>";

p.text = {
    status: "generated",
    div: DivNarrative
};


fhirClient.create({
        resourceType: 'Patient',
        body: p,
    }).then((data) => {
        var NewId = data.id;
        console.log("Patient Id :" + NewId)
        var o = new Object();
        o.resourceType = "Observation";
        ///Observation: Lab –Serum Creatinine Value: 65 umol/L, March 3, 2020 07:00:00 EST /
        // LOINC Code: 14682-9 (http://loinc.org)

        o.subject = {
            display: data.name[0].given[0] + " " + data.name[0].family,
            reference: "Patient/" + NewId
        };

        o.issued = "2020-03-03T07:00:00Z0300";
        o.valueQuantity = {
            value: 65,
            unit: "umol/L",
            system: "http://unitsofmeasure.org/",
            code: "umol/L"
        };
        o.code = {
            coding: [{
                system: "http://loinc.org",
                code: "14682-9",
                display: "Serum Creatinine"
            }]

        };
        var NarrativeObs =
            "<div xmlns='http://www.w3.org/1999/xhtml'>" +
            "Code:" + o.code.coding[0].system + ":" + o.code.coding[0].code + ":" + o.code.coding[0].display + "<br/>" +
            "Value:" + o.valueQuantity.value + " " + o.valueQuantity.unit + "<br/>" +
            "Subject:" + o.subject.display + "<br/>" +
            "Issued:" + o.issued + "<br/>" +
            "</div>";

        o.text = {
            status: "generated",
            div: NarrativeObs
        };
        fhirClient.create({
                resourceType: 'Observation',
                body: o,
            }).then((dataO) => {
                console.log("Observation Id:" + dataO.id)
            })
            .catch((error) => {
                var errorText = JSON.stringify(error);
                console.log(errorText)
            })

    })
    .catch((error) => {
        var errorText = JSON.stringify(error);
        console.log(errorText)
    });