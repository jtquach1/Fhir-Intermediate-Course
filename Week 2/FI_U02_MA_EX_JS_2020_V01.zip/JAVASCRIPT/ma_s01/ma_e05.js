const express = require('express')
const app = express()
const port = 8000
const Client  = require('fhir-kit-client')
// This Example creates a Practitioner instance
app.get('/', (req, res) => 
{
    const fhirClient = new Client({
    baseUrl: 'http://fhir.hl7fundamentals.org/r4',
    customHeaders:{
        "Content-Type":"application/fhir+json",
        "Accept":"application/fhir+json"
        }
       
    }
);


const newPractitioner = {

        "resourceType": "Practitioner",
        "identifier": [
          {
            "system": "(http://canada.gov/cpn",
            "value": "51922"
          }
        ],
        "active": true,
        "name": [
          {
            "family": "Dellacroix",
            "given": [
              "Madeleine"
            ]
          }
        ],
        "telecom": [
          {
            "system": "phone",
            "value": "613-555-0192 "
          },
          {
            "system": "email",
            "value": "qcpamxms9dq@groupbuff.com"
          }
        ],
        "address": [
          {
            "line": [
              "3766 Papineau Avenue"
            ],
            "city": "Montreal",
            "state": "Quebec",
            "postalCode": "H2K 4J5",
            "country": "Canada"
          }
        ],
        "qualification": [
          {
            "code": {
              "coding": [
                {
                  "system": "http://canada.gov/cpnq",
                  "code": "OB/GYN"
                }
              ]
            }
          }
        ]
      };  

  fhirClient.create({
    resourceType: 'Practitioner',
    body: newPractitioner,
  }).then((data) => { 
        var NewId=data.id;
        res.send("Id:"+NewId);})
    .catch((error) => { 
        var errorText=JSON.stringify(error);
        res.send(errorText) 
    });

  
});
app.listen(port, () => console.log('ma_e05 listening on port ${port}!'))
