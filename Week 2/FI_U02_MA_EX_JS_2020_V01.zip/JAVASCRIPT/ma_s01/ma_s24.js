//Micro Assignment S 24 - Parse XML resource
//Print to the console the patient name and identifier
const fs = require('fs');
var path = require('path');
var resourcePath = path.join(__dirname, '.', 'FHIR_RESOURCES', 'PATIENT_EXTENSIONS.XML');
var contents = fs.readFileSync(resourcePath, 'utf8');
var Fhir = require('fhir').Fhir;
var fhir = new Fhir();
var pat = fhir.xmlToObj(contents);
PatientName = pat.name[0].family + "," + pat.name[0].given[0];
PatientIdentifier = pat.identifier[0].system + ":" + pat.identifier[0].value;
console.log(PatientName);
console.log(PatientIdentifier);