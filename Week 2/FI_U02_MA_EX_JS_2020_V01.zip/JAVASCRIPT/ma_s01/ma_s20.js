//Micro Assignment S 20 - Populate a Transaction Bundle
//For two observations (systolic/device), a device and a patient
//uuid: to created UUIDs for entry identification and reference between resources
const uuid = require('uuid');
//Transactions should be posted to the endpoint of the FHIR server, no specific class route
var urlFHIREndpoint = 'http://fhir.hl7fundamentals.org/r4';
var FullURL = urlFHIREndpoint + "/";

//Initializing the Bundle
var MyBundle = new Object();
MyBundle.resourceType = 'Bundle';
MyBundle.id = uuid.v4();

//Setting up our patient resource
var MyPatient = {

    resourceType: "Patient",
    identifier: [{
        use: "official",
        system: "http://citizens-id.gov/citizens",
        value: "123456X1000"
    }],
    active: true,
    name: [{
        use: "official",
        family: "Alvarado for The Bundle",
        given: [
            "Adama Licia"
        ],
        prefix: [
            "Ms."
        ],

    }],
    telecom: [{
            system: "phone",
            value: "(777) 888-9999"
        },
        {
            system: "email",
            value: "alvaradolicia@everymail.com"
        }
    ],
    gender: "male",
    birthDate: "1978-06-20",
    address: [{
        line: [
            "1234 Elm Street"
        ],
        city: "New York",
        state: "NY",
        postalCode: "90210",
        country: "US"
    }],

};
//Token for conditional search of the patient
var PatToken = MyPatient.identifier[0].system + "|" + MyPatient.identifier[0].value;
var PatUrl = "Patient?identifier=" + PatToken;
//Display for patient reference in other resources
var PatientDisplay = MyPatient.name[0].family + "," + MyPatient.name[0].given[0];
//Entry Identifier for referencing the patient resource (inside of the transaction)
PatientEntryId = uuid.v4();
var PatientRef = "Patient/" + PatientEntryId;
//First entry in the bundle: The Patient
var MyPatientEntry = {
    fullUrl: PatientEntryId,
    resource: MyPatient,
    request: {
        method: "PUT",
        url: PatUrl
    }
};

//Device creating the observations
var MyDevice = {
    resourceType: "Device",
    identifier: [{ system: "http://wwww.americandevices.com", value: "123456" }],
    deviceName: [{
        "name": "BLOOD PRESSURE MASTER"
    }],
    manufacturer: "AMERICAN BLOOD PRESSURE DEVICES",
    modelNumber: "2000 PLUS",
    serialNumber: "123456",
    patient: { reference: PatientRef, display: PatientDisplay }

}

//Token for conditional search of the device
var DevToken = MyDevice.identifier[0].system + "|" + MyDevice.identifier[0].value;
var DevUrl = "Device?identifier=" + DevToken;
//Display for device reference in other resources
var DevDisplay = MyDevice.deviceName.name;
//Entry Identifier for referencing the device resource (inside of the transaction)
DeviceEntryId = uuid.v4();
var DevRef = "Device/" + DeviceEntryId;
//Second entry in the bundle: The Patient
var MyDeviceEntry = {
    fullUrl: DeviceEntryId,
    resource: MyDevice,
    request: {
        method: "PUT",
        url: DevUrl
    }
};

//Initialize the bundle with the first two entries: patient, device
MyBundle.entry = [];
MyBundle.entry.push(MyPatientEntry);
MyBundle.entry.push(MyDeviceEntry);

//Here we have all the observations we need to save
//Since everything is LOINC, we don´t need to specify it in the array
//Just code, display, value and unit

var ObservationsToSave = [
    { code: "8480-6", display: "Systolic Blood Pressure", value: 120.0, unit: 'mmHG' },
    { code: "8462-4", display: "Diastolic Blood Pressure", value: 80.0, unit: 'mmHG' }
];

//Now for each observation
ObservationsToSave.forEach(obs => {

    //We create a new Observation resource, with the datetime:now, and the values

    var MyObs = {
        resourceType: "Observation",
        issued: JSON.stringify(Date),
        ValueQuantity: { value: obs.value, unit: obs.unit, code: obs.unit, system: "http://unitsofmeasure.org" },
        code: { coding: { system: "http://loinc.org", code: obs.code, display: obs.display } },
        subject: { reference: PatientRef, display: PatientDisplay },
        device: { reference: DevRef, display: DevDisplay }
    }

    //Here we just create the observation, no conditional creations, so we don´t PUT but POST
    MyObsEntryId = uuid.v4();

    var MyObsEntry = {
        fullUrl: MyObsEntryId,
        resource: MyObs,
        request: {
            method: "POST",
            url: "Observation"
        }
    };

    MyBundle.entry.push(MyObsEntry);

});



//We call the FHIR endpoint with our parameters
const axios = require('axios');

axios.post(FullURL, MyBundle)
    .then(response => {
        //We check the response status
        var data = response.data; { console.log(JSON.stringify(data)); }
    })
    //Any other problem, we failed
    .catch(error => {
        console.log(JSON.stringify(error.response.data));
    });