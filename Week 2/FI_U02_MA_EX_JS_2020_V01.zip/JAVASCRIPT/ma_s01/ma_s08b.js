  // This MicroAssignment extracts capabilities from 
  // the server statement using fhir-kit-client
  // capability tool
  //a) Can this server do conditional updates on Patient?
  //b) Which interactions does this server support on Practitioner?
  //c) Can this server search patient by birthdate?
  //d) Which search parameters does this server support for Observation?


  const Client         = require('fhir-kit-client');
  const CapabilityTool = require('fhir-kit-client/lib/capability-tool');
  const fhirClient = new Client({
  baseUrl: 'http://fhir.hl7fundamentals.org/r4',
  
  customHeaders:{
      "Content-Type":"application/fhir+json",
      "Accept":"application/fhir+json"
      }
      
  });
  fhirClient.capabilityStatement(
  ).then((capabilityStatement) => {
    console.log("Analyzing Capabilities for");
    console.log(fhirClient.baseUrl);
    // Initializing the Cap. Tool with the actual statement from the server
 const capabilities = new CapabilityTool(capabilityStatement);
//a) Can this server do conditional updates on Patient?
 const conditionalUpdateSupport = capabilities.capabilityContents({
  resourceType: 'Patient',
  capabilityType: 'conditionalUpdate'
 });
  console.log("a) Can this server do conditional updates on Patient?");
  console.log(conditionalUpdateSupport);   
//b) Which interactions does this server support on Practitioner?
const supportedPractitionerInteractions = 
capabilities.interactionsFor({ resourceType: 'Practitioner'});
console.log("b) Which interactions does this server support on Practitioner?");
console.log(supportedPractitionerInteractions);
 
//c) Can this server search Patient by birthdate?
const patientBDSearchSupport = capabilities.resourceSearch('Patient', 'birthdate');
console.log("c) Can this server search Patient by birthDate?");
console.log(patientBDSearchSupport);

//d) Which search parameters does this server support for Observation?
const ObservationSearchParam = capabilities.searchParamsFor({ resourceType: 'Observation'});
console.log("Which search parameters does this server support for Observation?");
console.log(ObservationSearchParam);


})
    .catch((error) => { 
        console.log("Error");
        var errorText=JSON.stringify(error);
        console.log(errorText);
    });
  


