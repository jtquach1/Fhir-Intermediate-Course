//Micro Assignment S 10 - Conditional Creation of Patient Resource
//Neither fhir-kit-client nor any of the other JS libraries
//support conditional update/create
//at the time
//of publishing this course.
//To achieve the same result, we resorted to use a 
//generic http library
//
  const axios   = require('axios');
  var urlFHIREndpoint='http://fhir.hl7fundamentals.org/r4/';
  var ResourceClass  ='Patient';
  var SearchParameters  = 'identifier=http://central.patient.id/ident|88999888991';
  var FullURL = urlFHIREndpoint+ResourceClass+"?"+SearchParameters;
  
  const newPatient = 
  {
    "resourceType": "Patient",
    "identifier": [
      {
        "system": "http://central.patient.id/ident",
        "value": "88999888991"
      }
    ],
    "name": [
      {
        "family": "Smith",
        "given": [
          "Alan"
        ]
      }
    ],
    "birthDate":"1968-05-06",
    "gender": "male"
  };  

  //We call the FHIR endpoint with our parameters
  
  axios.put(FullURL,newPatient)
  .then(response => {
    //We check the response status
    var status=response.status;
    //201: Created    ,  200: OK (Found)
    if (status==201)
    {console.log("Created "+response.data.id)}
    else 
    {console.log("Existing "+response.data.id)}
  })
  //Any other problem, we failed, like in 412.Precondition Failed
  .catch(error => {
    console.log(error.response.statusText);
  });
