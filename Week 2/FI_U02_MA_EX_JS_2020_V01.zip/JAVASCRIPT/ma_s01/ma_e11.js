const Client = require('fhir-kit-client')
const fhirClient = new Client({
    baseUrl: 'http://fhir.hl7fundamentals.org/r4',
    customHeaders: {
        "Content-Type": "application/fhir+json",
        "Accept": "application/fhir+json"
    }

});
/*
clinicalStatus :
      system:"http://terminology.hl7.org/CodeSystem/condition-clinical",
      code  :"active"
stage:
    type= system: "http://snomed.info/sct", code: "422375001", display: "Carcinoma of Colon, Clinical stage III"
    Summary= system: "http://snomed.info/sct", code: "385356007", display: "Tumor Stage Finding"
    Assessment = Reference = "DiagnosticReport/201993"  
onset:
    Age: 10y
    
  
*/

var cnd = new Object;
cnd.resourceType = 'Condition';

//Clinical Status: no repetitions
cnd.clinicalStatus = { //but coding MAY repeat so it's an array
        coding: [{
            system: "http://terminology.hl7.org/CodeSystem/condition-clinical",
            code: "active"
        }]
    },

    //Stage may repeat so we will include an array, in this case with only one element, which we push into the array
    cnd.stage = [];

cnd.stage.push({
    //0..1: type may NOT repeat so we will include a single element
    type: { //but coding MAY repeat so it's an array
        coding: [{
            system: "http://snomed.info/sct",
            code: "422375001"
        }]
    },
    //0..1: summary may NOT repeat so we will include a single element
    summary: { //but coding MAY repeat so it's an array
        coding: [{
            system: "http://snomed.info/sct",
            code: "385356007"
        }]
    },
    //assessment may repeat so we include an array
    assessment: [{ reference: "DiagnosticReport/201993" }]
});
//Only one subject, mandatory
cnd.subject = { reference: "Patient/123722" };

cnd.onsetAge = {
    value: 18,
    code: "Y",
    unit: "Y"
};


cnd.text = {
    status: "empty"

};
//The element is populated
var result = "No Clinical Status";
if (cnd.clinicalStatus) {
    //And the coding is also populated 
    if (cnd.clinicalStatus.coding) {
        //And cardinality is at least what I am searching for
        if (cnd.clinicalStatus.coding.length > 0) {
            //Then I extract the value
            result = cnd.clinicalStatus.coding[0].code +
                " (" + cnd.clinicalStatus.coding[0].system + ")";
            console.log("Clinical Status Retrieved");
            console.log(result);
        }
    }
};
//We need to get the value of the Condition.onSet in only one string to show it to the user
//onSet is a choice so we can extract one of these: Age, DateTime, Period, Range, String
var onsetValue = "-";
var onsetType = "No Value"
if (cnd.onsetAge) {
    onsetType = "Age";
    onsetValue = cnd.onsetAge.value + " " + cnd.onsetAge.unit;
} else {
    if (cnd.onsetDateTime) {
        onsetType = "DateTime";
        onsetValue = cnd.onsetDateTime;
    } else
    if (cnd.onsetPeriod) {
        onsetType = "Period";
        onsetValue = cnd.onsetPeriod.start;
        if (cnd.onsetPeriod.end)
            onsetValue = onsetValue + "-" + cnd.onsetPeriod.start;

    } else {
        if (cnd.onsetRange) {
            onsetType = "Range";
            onsetValue = cnd.onsetRange.low.value + " " + cnd.onsetRange.low.unit;
            if (cnd.onsetRange.high) { onsetValue = cnd.onsetRange.high.value + " " + cnd.onsetRange.high.unit; }

        } else {
            if (cnd.onsetString) {
                onsetType = "String";
                onsetValue = cnd.onsetString;
            }
        }
    }
};
console.log("Condition On Set Type:" + onsetType);
console.log("Condigion On Set Value:" + onsetValue);

fhirClient.create({
        resourceType: 'Condition',
        body: cnd,
    }).then((data) => {
        var NewId = data.id;
        console.log("Condition Id :" + NewId)
    })
    .catch((error) => {
        var errorText = JSON.stringify(error);
        console.log(errorText)
    });