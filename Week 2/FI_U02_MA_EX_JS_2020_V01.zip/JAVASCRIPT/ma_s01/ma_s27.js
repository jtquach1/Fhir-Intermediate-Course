/*
This example implements searches for three use cases in Argonaut PD Guide
a. Search for all patients with last (family) name exactly = “Smith”, gender=male, born after 05-May-1965
b. Search for the patient with identifier [system] http://hospital.gov/patients [value] 9999999 (Medical Record Number)
 
*/

const Client = require('fhir-kit-client');
const CapabilityTool = require('fhir-kit-client/lib/capability-tool');
const fhirClient = new Client({
    baseUrl: 'http://fhir.hl7fundamentals.org/r4',
    customHeaders: {
        "Content-Type": "application/fhir+json",
        "Accept": "application/fhir+json"
    }

});

//change the selected option to do the specific search
//a: family name
//b: identifier

var option = 'b';
var resourceClass = "";
var searchCriteria = [];
const MaxPerPage = '10';
switch (option) {
    case "a":
        resourceClass = "Patient";
        searchCriteria = { _count: MaxPerPage, family: 'Smith', gender: 'male', birthdate: 'ge1965-05-05' }
        break;
    case "b":
        resourceClass = "Patient";
        searchCriteria = { _count: MaxPerPage, identifier: "http://hospital.gov/patients|9999999" }
        break;
    default:
        break;
};

fhirClient
    .search({ resourceType: resourceClass, searchParams: searchCriteria })
    .then((response) => {
        console.log(response);
        return response;
    })
    .then((response) => {
        console.log(response);
        return fhirClient.nextPage(response);
    })
    .then((response) => {
        console.log(response);
        return fhirClient.prevPage(response);
    })
    .catch((error) => {
        console.error(JSON.stringify(error));
    });