//Micro Assignment S 12 - ValueSet Expand
//Neither fhir-kit-client nor any of the other JS libraries
//support terminology operations
//at the time
//of publishing this course.
//To achieve the same result, we resorted to use a 
//generic http library
//
  const axios   = require('axios');
  var urlFHIREndpoint='https://snowstorm-alpha.ihtsdotools.org/fhir/';
  var ResourceClass  ='ValueSet';
  var OperationName="$expand"
  var url= "http://snomed.info/sct?fhir_vs=isa/73211009"
  var filter= "";
  var Parameters="url="+url
  if (filter!=""){ Parameters=Parameters+"&"+"filter="+filter;}
  var FullURL = urlFHIREndpoint+ResourceClass+"/"+OperationName+"?"+Parameters;
  
  //We call the FHIR endpoint with our parameters
  
  axios.get(FullURL)
  .then(response => {
    //We check the response status
    var data=response.data;
    {console.log(JSON.stringify(data));}
  })
  //Any other problem, we failed
  .catch(error => {
    console.log(error);
  });
