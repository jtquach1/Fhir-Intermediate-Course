//Micro Assignment S 13 - ValueSet Code Validation
//Neither fhir-kit-client nor any of the other JS libraries
//support terminology operations
//at the time
//of publishing this course.
//To achieve the same result, we resorted to use a 
//generic http library
//
  const axios   = require('axios');
  var urlFHIREndpoint='https://fhir.loinc.org';
  var ResourceClass  ='ValueSet';
  var OperationName="$validate-code"
  var ValueSet= "LG33055-1"
  var Code= "8867-4";
  var CodeSystem="http://loinc.org";
  var Parameters="system="+CodeSystem;
  Parameters=Parameters+ "&"+"code="+Code;
           
   var fullURL = urlFHIREndpoint+"/"+ResourceClass+"/"+ValueSet+"/"+OperationName+"?"+Parameters;
   const hash = 'ZGllZ29rYW1pbmtlcjpzdXBlcmxvaW5jMjAxOS4K'
   const Basic = 'Basic ' + hash;
   axios.get(fullURL, {headers : { 'Authorization' : Basic }})
  .then(response => {
    //We check the response status
    var data=response.data;
    {console.log(JSON.stringify(data));}
  })
  //Any other problem, we failed
  .catch(error => {
    console.log(error);
  });
