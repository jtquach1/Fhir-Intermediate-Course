  // This Micro Assignment deletes a Patient instance

  const Client  = require('fhir-kit-client')
  const fhirClient = new Client({
  baseUrl: 'http://fhir.hl7fundamentals.org/r4',
  customHeaders:{
      "Content-Type":"application/fhir+json",
      "Accept":"application/fhir+json"
      }
      
  });

  fhirClient.delete({
    resourceType: 'Patient',
    id:17357,
  }).then((data) => { 
        console.log("Success");})
    .catch((error) => { 
        console.log("Error");
        var errorText=JSON.stringify(error);
        console.log(errorText);
    });
  


