// This Micro Assignment updates a Patient instance

const Client  = require('fhir-kit-client')
    const fhirClient = new Client({
    baseUrl: 'http://fhir.hl7fundamentals.org/r4',
    customHeaders:{
        "Content-Type":"application/fhir+json",
        "Accept":"application/fhir+json"
        }
       
    }
);
console.log("About to retrieve patient");
fhirClient.read({
    resourceType: 'Patient',
    id: 123208,
  }).then((MyPatient) => {UpdatePatient(MyPatient)})
    .catch((error)=>{console.log(JSON.stringify(error))});
     
function UpdatePatient(MyPatient)
{
console.log("My Patient obtained");
console.log(JSON.stringify(MyPatient));    

MyPatient.telecom=
         [
          {
            "system": "phone",
            "value": "613-555-5555"
          },
          {
            "system": "email",
            "value": "qcpamxms9dq@groupbuff.com"
          }
        ];
MyPatient.address=
         [ {
            "line": [
              "3600 Papineau Avenue"
            ],
            "city": "Montreal",
            "state": "Quebec",
            "postalCode": "H2K 4J5",
            "country": "Canada"
          }];
 
          console.log("My Patient edited");
console.log(JSON.stringify(MyPatient));    

  fhirClient.update(
      {
    resourceType: 'Patient',
    id:123208,
    body: MyPatient,
  }).then((data) => { 
        var NewVer=data.meta.versionId;
        console.log("Updated versionId:"+NewVer);})
    .catch((error) => { 
        console.log("Error");
        var errorText=JSON.stringify(error);
        console.log(errorText);
    });
  
}
