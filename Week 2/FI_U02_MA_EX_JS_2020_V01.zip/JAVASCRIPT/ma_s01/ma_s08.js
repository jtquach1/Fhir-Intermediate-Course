  // This Micro Assignment gets the Capability Statement
  // from the FHIR server
  const Client  = require('fhir-kit-client')
  const fhirClient = new Client({
  baseUrl: 'http://fhir.hl7fundamentals.org/r4',
  customHeaders:{
      "Content-Type":"application/fhir+json",
      "Accept":"application/fhir+json"
      }
      
  });

  fhirClient.capabilityStatement(
  ).then((data) => { 
        console.log(JSON.stringify(data));})
    .catch((error) => { 
        console.log("Error");
        var errorText=JSON.stringify(error);
        console.log(errorText);
    });
  


