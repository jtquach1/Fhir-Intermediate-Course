const Client  = require('fhir-kit-client')
// This Micro Assignment implements 
// basic auth with fhir-kit-client
    authinfo="user:password";
    let buff = new Buffer.from(authinfo);
    let base64data = buff.toString('base64');
    const fhirClient = new Client({
    baseUrl: 'http://fhir.hl7fundamentals.org/r4',
    customHeaders:["Authorization","Basic " + base64data]});
    console.log ("Basic "+base64data);
