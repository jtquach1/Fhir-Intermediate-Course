const Client = require('fhir-kit-client');
const CapabilityTool = require('fhir-kit-client/lib/capability-tool');
const fhirClient = new Client({
    baseUrl: 'http://fhir.hl7fundamentals.org/r4',

    customHeaders: {
        "Content-Type": "application/fhir+json",
        "Accept": "application/fhir+json"
    }

});
fhirClient
    .search({ resourceType: 'Patient', searchParams: { _count: '10', name: 'Smith' } })
    .then((response) => {
        console.log(response);
        return response;
    })
    .then((response) => {
        console.log(response);
        return fhirClient.nextPage(response);
    })
    .then((response) => {
        console.log(response);
        return fhirClient.prevPage(response);
    })
    .catch((error) => {
        console.error(error);
    });