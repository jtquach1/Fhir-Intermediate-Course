const Client  = require('fhir-kit-client')
// This Micro Assignment implements 
// reading a resource knowing its complete url
    const fhirClient = new Client({
    baseUrl: 'http://fhir.hl7fundamentals.org/r4',
    });
 
//Direct Read Knowing URL
fhirClient.resolve(
    { reference: 'http://fhir.hl7fundamentals.org/r4/Patient/17343' })
    .then((MyPatient) =>
  
  {  
      var pdata=JSON.stringify(MyPatient);
      console.log(pdata);  
      
    });
