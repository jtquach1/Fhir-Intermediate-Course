const Client  = require('fhir-kit-client')
// This Micro Assignment implements 
// reading the last version of a resource 
// knowing the logical id
    const fhirClient = new Client({
    baseUrl: 'http://fhir.hl7fundamentals.org/r4',
    }
);
 
//Direct Read Knowing Resource Id
fhirClient.read({
    resourceType: 'Patient',
    id: 17343,
  }).then((MyPatient) =>
  
  {  
      var pdata=JSON.stringify(MyPatient);
      console.log(pdata);  
      
    });
