//Micro Assignment S 14 - Validation
//Neither fhir-kit-client nor any of the other JS libraries
//support operations
//at the time
//of publishing this course.
//To achieve the same result, we resorted to use a 
//generic http library: axios
//
const axios   = require('axios');
const fs = require('fs');
var path = require('path');
var resourcePath = path.join(__dirname, '.', 'FHIR_RESOURCES', 'PATIENT.XML');
var contents= fs.readFileSync(resourcePath, 'utf8');
var urlFHIREndpoint='http://fhir.hl7fundamentals.org/r4';
var ResourceClass="Patient";
var OperationName="$validate";
var FullURL = urlFHIREndpoint+"/"+ResourceClass+"/"+OperationName;
//We call the FHIR endpoint with our parameters
axios.post(
    FullURL, contents,
    {headers :  { "Content-Type":"application/fhir+xml",
    "Accept":"application/fhir+json"}
    }
   )
.then(response => {
  //We check the response status
  var data=response.data;
  {console.log(JSON.stringify(data));}
})
//Any other problem, we failed
.catch(error => {
  var message=error;
  console.log(message.response.data.text);
});
