//Micro Assignment S 12 - ValueSet Expand
//Neither fhir-kit-client nor any of the other JS libraries
//support terminology operations
//at the time
//of publishing this course.
//To achieve the same result, we resorted to use a 
//generic http library
//
const axios   = require('axios');
const fs = require('fs');
 
var contents = fs.readFileSync('FHIR_RESOURCES\PATIENT.XML', 'utf8');
var urlFHIREndpoint='http://fhir.hl7fundamentals.org/r4';
var OperationName="$validate";
var Parameters="resource="+contents;
var FullURL = urlFHIREndpoint+"/"+OperationName+"?"+Parameters;

//We call the FHIR endpoint with our parameters

axios.get(FullURL)
.then(response => {
  //We check the response status
  var data=response.data;
  {console.log(JSON.stringify(data));}
})
//Any other problem, we failed
.catch(error => {
  console.log(error);
});
