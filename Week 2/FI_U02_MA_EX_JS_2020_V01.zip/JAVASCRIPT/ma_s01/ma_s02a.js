const Client  = require('fhir-kit-client')
// This Micro Assignment implements 
// bearer token with fhir-kit-client
    const fhirClient = new Client({
    baseUrl: 'http://fhir.hl7fundamentals.org/r4',
    bearerToken: 'ya29.QQIBibTwvKkE39hY8mdkT_mXZoRh7Ub9cK9hNsqrxem4QJ6sQa36VHfyuBe'
    });
    console.log ("bearer token header set");
