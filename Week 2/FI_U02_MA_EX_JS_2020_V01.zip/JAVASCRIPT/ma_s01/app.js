const express = require('express')
const app = express()
const port = 8000
const Client  = require('fhir-kit-client')

app.get('/', (req, res) => 
{
    const fhirClient = new Client({
    baseUrl: 'http://fhir.hl7fundamentals.org/r4'
    });
  
    res.send('I am just a skeleton, so I do nothing!')
})

app.listen(port, () => console.log(`Example app listening on port ${port}!`))