//Example  S 31 - Building an IPS Document
const uuid = require('uuid');


/*
Minimum Resources for an IPS are:
Composition (1st Entry)
+Patient
+Organization
+Author
+MedicationStatement
+Condition
+AllergyIntolerance

 */
// We set up for the fullUrl of each Entry the internal Ids, for all the resources
// They will serve as references between the resources inside the bundle

var CompositionEntryId = uuid.v4();
var OrganizationEntryId = uuid.v4();
var PatientEntryId = uuid.v4();
var AuthorEntryId = uuid.v4();
var MedicationStatementEntryId = uuid.v4();
var ConditionEntryId = uuid.v4();
var AllergyIntoleranceMedicationEntryId = uuid.v4();
var AllergyIntoleranceFoodEntryId = uuid.v4();

//We populate the organization
//IPS Must-Support: identifier, name, telecom, address

var org = {
    resourceType: 'Organization',

    identifier: [{
        use: "official",
        system: "http://npi.org/identifiers",
        value: "7777777"
    }],
    name: "New York General Clinic",
    address: [{
        line: [
            "1234 Org Street"
        ],
        city: "New York",
        state: "NY",
        postalCode: "90210",
        country: "US"
    }],
    telecom: [{
            system: "phone",
            value: "(555) 888-7777"
        },

    ]
};

org.meta = { profile: ["http://hl7.org/fhir/uv/ips/StructureDefinition/Organization-uv-ips"] };

// Setup a Reference to this Organization
orgRef = { reference: "Organization/" + OrganizationEntryId, display: org.name };

var pra = {

    "resourceType": "Practitioner",
    "identifier": [{
        "system": "http://physicians-id.gov/physicians",
        "value": "8888888"
    }],
    "active": true,
    "name": [{
        "family": "Practitio",
        "given": [
            "Thomas"
        ]
    }],
    "telecom": [{
            "system": "phone",
            "value": "(555) 666-6777"
        },
        {
            "system": "email",
            "value": "practitio@everymail.com"
        },

    ],
    "address": [{
        "line": [
            "4321 Med Street"
        ],
        "city": "New York",
        "state": "NY",
        "postalCode": "90210",
        "country": "USA"
    }]
};

pra.meta = { profile: ["http://hl7.org/fhir/uv/ips/StructureDefinition/Practitioner-uv-ips"] };

//Setup a reference to this practitioner

var authorRef = { reference: "Practitioner/" + AuthorEntryId, display: pra.name[0].family + "," + pra.name[0].given[0] };

//We populate the patient
//IPS Must-Support: name (family/given), telecom, gender, birthDate, address (line/city/state/postalCode
// /country) , contact (relationship,name, telecom, address, organization - ref , communication ,
// generalPractitioner

pat = {

    resourceType: "Patient",
    identifier: [{
        use: "official",
        system: "http://citizens-id.gov/citizens",
        value: "123456X1000"
    }],
    active: true,
    name: [{
        use: "official",
        family: "Alvarado for The Bundle",
        given: [
            "Adama Licia"
        ],
        prefix: [
            "Ms."
        ],

    }],
    telecom: [{
            system: "phone",
            value: "(777) 888-9999"
        },
        {
            system: "email",
            value: "alvaradolicia@everymail.com"
        }
    ],
    gender: "male",
    birthDate: "1978-06-20",
    address: [{
        line: [
            "1234 Elm Street"
        ],
        city: "New York",
        state: "NY",
        postalCode: "90210",
        country: "US"
    }],
    generalPractitioner: authorRef,
    managingOrganization: orgRef
};
pat.meta = { profile: ["http://hl7.org/fhir/uv/ips/StructureDefinition/Patient-uv-ips"] };
patientDisplay = pat.name[0].family + "," + pat.name[0].given[0];
patientRef = { reference: "Patient/" + PatientEntryId, display: patientDisplay };


/*

Create the composition resource
Composition resource mandatory elements for IPS are
identifier, status, type
author, title, confidentiality
attester, custodian
Mandatory sections for IPS: Problems, Medications, Allergies

/*
Unique identifier for the document
Document status
Document Type: IPS
Document Subject : The Patient
Document created now!
Author
*/
var cmp = {
    resourceType: "Composition",
    identifier: [{
        system: "http://myhospital.org.uk",
        value: uuid.v4()
    }],
    status: "final",
    type: { coding: { system: "http://loinc.org", code: "60591-5", display: "Patient Summary Document" } },
    subject: patientRef,
    date: JSON.stringify(Date),
    author: authorRef,
    confidentiality: "N",
    title: "Patient Summary For " + patientDisplay,
    attester: {
        mode: "legal",
        party: orgRef,
        custodian: orgRef
    }
};

cmp.meta = { profile: ["http://hl7.org/fhir/uv/ips/StructureDefinition/Composition-uv-ips"] };
// Sections


// Allergies

var almenarrative = {
    status: "generated",
    div: '<div xmlns="http://www.w3.org/1999/xhtml">ALLERGY - MEDICATION - CRITICALITY -HIGH -PENICILLIN</div>'
};

// Section Entries: Allergy to Penicillin
var peni = {
    resourceType: "AllergyIntolerance",
    type: "allergy",
    category: "medication",
    criticality: "high",
    patient: patientRef,
    code: { coding: { system: "http://snomed.info/sct.org", code: "373270004", display: "Substance with penicillin structure and antibacterial mechanism of action (substance)" } },
    text: almenarrative,
    meta: { profile: ["http://hl7.org/fhir/uv/ips/StructureDefinition/AllergyIntolerance-uv-ips"] }
};

var peniRef = { reference: "AllergyIntolerance/" + AllergyIntoleranceMedicationEntryId };


// No known food allergies

var alfonarrative = {
    status: "generated",
    div: '<div xmlns="http://www.w3.org/1999/xhtml"> No known food allergies</div>'
};


var nofo = {
    resourceType: "AllergyIntolerance",
    type: "allergy",
    category: "food",
    patient: patientRef,
    code: { coding: { system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips", code: "no-known-food-allergies", display: "No Known Food Allergies" } },
    text: alfonarrative,
    meta: { profile: ["http://hl7.org/fhir/uv/ips/StructureDefinition/AllergyIntolerance-uv-ips"] }
};


var nofoRef = { reference: "AllergyIntolerance/" + AllergyIntoleranceFoodEntryId };


var alernarrative = {
    status: "generated",
    div: '<div xmlns="http://www.w3.org/1999/xhtml">Food : Not Known / Medication: Allergy To Penicillin</div>'
};

cmp.section = [];

cmp.section.push({
    code: { coding: { system: "http://loinc.org", code: "48765-2", display: "Allergies and Intolerance Document" } },
    title: "Allergies and Intolerances",
    text: alfonarrative,
    entry: [peniRef, nofoRef]
});

//Problems
/*
     Must-Support by IPS for Condition
     clinicalStatus
     verificationStatus
     category
     severity
     code
     subject
     onsetDateTime
     asserter
     */
var cond = {
    resourceType: "Condition",
    clinicalStatus: { coding: { system: "http://terminology.hl7.org/CodeSystem/condition-clinical", code: "active", display: "Active" } },
    verificationStatus: { coding: { system: "http://terminology.hl7.org/CodeSystem/condition-ver-status", code: "confirmed", display: "Confirmed" } },
    category: { coding: { system: "http://loinc.org", code: "75326-9", display: "Problem" } },
    severity: { coding: { system: "http://loinc.org", code: "LA6751-7", display: "Moderate" } },
    code: { coding: { system: "http://snomed.info/sct", code: "54329005", display: "Acute myocardial infarction of anterior wall" } },
    onsetDateTime: "2010-01-01",
    subject: patientRef,
    asserter: authorRef,
    text: {
        status: "generated",
        div: '<div xmlns="http://www.w3.org/1999/xhtml">Acute myocardial infarction of anterior wall, 01-Jan-2019, Active, Confirmed</div>'
    },
    meta: { profile: ["http://hl7.org/fhir/uv/ips/StructureDefinition/Condition-uv-ips"] }
}

var condRef = { reference: "Condition/" + ConditionEntryId };


cmp.section.push({
    code: { coding: { system: "http://loinc.org", code: "11450-4", display: "Problems" } },
    title: "Active Problems",
    text: cond.text,
    entry: [condRef]
});

var medi = {
    resourceType: "MedicationStatement",
    status: "active",
    medication: { coding: { system: "http://snomed.info/sct", code: "1108979001", display: "Clopidogrel" } },
    subject: patientRef,
    informationSource: authorRef,
    reasonReference: condRef,
    dosage: [{
        text: "75 mg orally once a day",
        route: { coding: { system: "http://standardterms.edqm.eu", code: "20053000", display: "Oral" } },
        timing: { coding: { system: "http://terminology.hl7.org/CodeSystem/v3-GTSAbbreviation", code: "QD", display: "Daily" } }
    }],
    text: {
        status: "generated",
        div: '<div xmlns="http://www.w3.org/1999/xhtml"> Clopidogrel, 75mg Orally, once a day</div>'
    },
    meta: { profile: ["http://hl7.org/fhir/uv/ips/StructureDefinition/MedicationStatement-uv-ips"] }
};

var mediRef = { reference: "MedicationStatement/" + MedicationStatementEntryId };

cmp.section.push({
    code: { coding: { system: "http://loinc.org", code: "10160-9", display: "Medications" } },
    title: "Medications",
    text: medi.text,
    entry: [mediRef]
});

//Initializing the Bundle
var my_ips = new Object();
my_ips.resourceType = 'Bundle';
my_ips.id = uuid.v4();
my_ips.type = "document"
    //Now that we have all our resources set up, we assemble our bundle entries
my_ips.entry = [];
my_ips.entry.push({ fullUrl: CompositionEntryId, resource: cmp });
my_ips.entry.push({ fullUrl: PatientEntryId, resource: pat });
my_ips.entry.push({ fullUrl: OrganizationEntryId, resource: org });
my_ips.entry.push({ fullUrl: AuthorEntryId, resource: pra });
my_ips.entry.push({ fullUrl: ConditionEntryId, resource: cond });
my_ips.entry.push({ fullUrl: MedicationStatementEntryId, resource: medi });
my_ips.entry.push({ fullUrl: AllergyIntoleranceMedicationEntryId, resource: peni });
my_ips.entry.push({ fullUrl: AllergyIntoleranceFoodEntryId, resource: nofo });

//Finally we create our document POSTing to the bundle endpoint of our server

const Client = require('fhir-kit-client')
const fhirClient = new Client({
    baseUrl: 'http://fhir.hl7fundamentals.org/r4',
    customHeaders: {
        "Content-Type": "application/fhir+json",
        "Accept": "application/fhir+json"
    }

});
fhirClient.create({
        resourceType: 'Bundle',
        body: my_ips,
    }).then((data) => {
        var NewId = data.id;
        console.log("Id:" + NewId);
    })
    .catch((error) => {
        var errorText = JSON.stringify(error);
        console.log(errorText)
    });