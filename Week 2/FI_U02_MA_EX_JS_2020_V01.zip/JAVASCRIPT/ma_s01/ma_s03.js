const Client  = require('fhir-kit-client')
// This Micro Assignment sets 
// content/type to  with fhir-kit-client
    const fhirClient = new Client({
    baseUrl: 'http://fhir.hl7fundamentals.org/r4',
    customHeaders:{
    "Content-Type":"application+fhir/json",
    "Accept":"application+fhir/json"
    }});
    
    console.log("customHeaders set"); 
