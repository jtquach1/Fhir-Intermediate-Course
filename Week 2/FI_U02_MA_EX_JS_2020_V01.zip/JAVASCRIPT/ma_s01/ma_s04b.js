const Client  = require('fhir-kit-client')
// This Micro Assignment implements 
// reading a resource knowing id and version
    const fhirClient = new Client({
    baseUrl: 'http://fhir.hl7fundamentals.org/r4',
    }
);
 
//Direct Read Knowing Resource Id and version
fhirClient.vread({
    resourceType: 'Patient',
    id: 17343,
    version:1
  }).then((MyPatient) =>
  
  {  
      var pdata=JSON.stringify(MyPatient);
      console.log(pdata);  
      
    });
