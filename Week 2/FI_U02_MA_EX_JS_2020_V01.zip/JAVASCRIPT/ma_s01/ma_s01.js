const Client  = require('fhir-kit-client')
    const fhirClient = new Client({
    baseUrl: 'http://fhir.hl7fundamentals.org/r4'
    });
    console.log('I am just a skeleton, so I do nothing!');
