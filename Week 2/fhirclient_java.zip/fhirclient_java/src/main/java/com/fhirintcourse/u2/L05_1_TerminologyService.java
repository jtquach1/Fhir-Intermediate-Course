package com.fhirintcourse.u2;

public class L05_1_TerminologyService {

    public String ExpandValuesetForCombo
    (  
    String ServerEndPoint,
    String url,
    String filter)
    {
    String aux="";    
    return aux;

}
}