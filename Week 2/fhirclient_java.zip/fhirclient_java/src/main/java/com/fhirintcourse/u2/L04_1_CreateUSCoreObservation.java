package com.fhirintcourse.u2;
public class L04_1_CreateUSCoreObservation {

    public String CreateUSCoreR4LabObservation
        (  
        String ServerEndPoint,
        String IdentifierSystem,
        String IdentifierValue,
        String ObservationStatusCode, 
        String ObservationDateTime,
        String ObservationLOINCCode,
        String ObservationLOINCDisplay,
        String ResultType,
        String NumericResultValue,
        String NumericResultUCUMUnit,
        String CodedResultSNOMEDCode,
        String CodedResultSNOMEDDisplay
        )
    {
       
    String aux="";
    return aux;
             }
         
}


