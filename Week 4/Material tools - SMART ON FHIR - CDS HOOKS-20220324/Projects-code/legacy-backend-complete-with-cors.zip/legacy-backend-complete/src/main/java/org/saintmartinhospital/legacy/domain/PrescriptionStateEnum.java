package org.saintmartinhospital.legacy.domain;


public enum PrescriptionStateEnum {
	VALID, RAW, DISRUPTED
}
