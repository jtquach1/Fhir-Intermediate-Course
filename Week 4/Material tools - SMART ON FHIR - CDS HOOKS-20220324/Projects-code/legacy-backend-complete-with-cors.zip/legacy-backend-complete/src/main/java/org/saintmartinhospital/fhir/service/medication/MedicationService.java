package org.saintmartinhospital.fhir.service.medication;

import ca.uhn.fhir.rest.api.server.IBundleProvider;
import org.hl7.fhir.r4.model.Medication;


public interface MedicationService {

	Medication findById( Integer medicationId );
	Medication create( Medication medication );
	IBundleProvider findLikeDisplay( String display );
			
}
