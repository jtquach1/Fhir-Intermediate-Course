package org.saintmartinhospital.fhir.config;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Component
@Order(1)
public class CorsFilter implements Filter {
	
	private static final String JSON_CONTENT_TYPE = "application/json";    
	private static final String OPTIONS_METHOD = HttpMethod.OPTIONS.toString();

	@Override
	public void doFilter( ServletRequest req, ServletResponse resp, FilterChain chain ) throws IOException, ServletException {
		HttpServletResponse response = (HttpServletResponse) resp;
		response.setHeader( "Access-Control-Allow-Origin", "*" );
		response.setHeader( "Access-Control-Allow-Methods", "OPTIONS, GET, POST, DELETE, PUT" );
		response.setHeader( "Access-Control-Max-Age", "3600" );
		response.setHeader( "Access-Control-Allow-Headers", "x-requested-with, Content-Type" );
		response.setContentType( JSON_CONTENT_TYPE );
		response.setCharacterEncoding( StandardCharsets.UTF_8.toString() );
		
		HttpServletRequest request = (HttpServletRequest) req;
		if( OPTIONS_METHOD.equalsIgnoreCase( request.getMethod() ) ) 
			response.setStatus( HttpStatus.OK.value() );
		else
			chain.doFilter( request, response );
	}
		
}