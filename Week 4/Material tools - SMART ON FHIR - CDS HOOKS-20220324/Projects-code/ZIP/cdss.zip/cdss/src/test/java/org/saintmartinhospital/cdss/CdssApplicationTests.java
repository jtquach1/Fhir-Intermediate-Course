package org.saintmartinhospital.cdss;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CdssApplicationTests {

	@Test
	void contextLoads() {
	}

}
