package org.saintmartinhospital.cdss.controller;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DiscoveryController {
    
    @RequestMapping(value = "/cdss/cds-services", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Object discovery() {
        JSONArray servicesDesc = new JSONArray();
        JSONObject services = new JSONObject();
        JSONObject serviceDesc = new JSONObject();
        JSONObject prefetch = new JSONObject();
        
        serviceDesc.put("hook","order-select");
        serviceDesc.put("title","Maximum dose");
        serviceDesc.put("description","Check the maximum dose when a new drug is prescribed.");
        serviceDesc.put("id","drug-max-dose");
        prefetch.put("activeMedicationRequest","MedicationRequest?subject={{context.patientId}}&status:exact=active");
        serviceDesc.put("prefetch",prefetch);
        servicesDesc.put(serviceDesc);
        services.put("services",servicesDesc);
        return services.toString();
    }
}
