package org.saintmartinhospital.cdss.controller;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.parser.IParser;
import ca.uhn.fhir.util.BundleUtil;
import com.google.gson.Gson;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.hl7.fhir.instance.model.api.IBaseBundle;
import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.CanonicalType;
import org.hl7.fhir.r4.model.Medication;
import org.hl7.fhir.r4.model.MedicationRequest;
import org.hl7.fhir.r4.model.Meta;
import org.hl7.fhir.r4.model.Narrative;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.cglib.core.CollectionUtils;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class DrugMaxDoseController {
    private static final FhirContext FHIR_CTX = FhirContext.forR4();
    private static final ArrayList<String> opioidsCodes = new ArrayList<>(
    Arrays.asList("857001","1049621"));
    
    @RequestMapping(value = "/cdss/cds-services/drug-max-dose", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Object drugMaxDose(@RequestBody Map<String, Object> body) throws Exception {       
        JSONParser parser = new JSONParser();
        IParser iParser = FHIR_CTX.newJsonParser();
                
        String hook = null;
        try{
            hook = body.get("hook").toString();
            if(!hook.equals("order-select")){
                throw new Exception("The hook for this CDSS service is order-select.");
            }
        } catch(Exception ex) {
            if(ex.getMessage() != null){
                throw new Exception(ex.getMessage());
            } else {
                throw new Exception("The CDSS service hook must be included.");
            }
            
        }
       String hookInstance = null;
       try{
         hookInstance = body.get("hookInstance").toString();
       } catch(Exception ex){
         throw new Exception("The UUID (hookInstance) that uniquely identifies this call to the CDSS service must be included.");
       }
       
       String fhirServer = null;
       if(body.get("fhirServer") != null) {
          fhirServer = body.get("fhirServer").toString();
       }
        
       LinkedHashMap fhirAuthorization = null;
       try{
         if(body.get("fhirAuthorization") == null && fhirServer != null) {
             throw new Exception("FHIR server access credentials must be included.");
         } else if(body.get("fhirAuthorization") != null  && fhirServer == null){
             throw new Exception("FHIR server URL must be included");
         }
         fhirAuthorization = new LinkedHashMap((Map) body.get("fhirAuthorization"));
       } catch(Exception ex){
         throw new Exception(ex.getMessage());
       }
       
       LinkedHashMap context = null;
       String resource = null;
       String resourceId = null;
       String selection = null;
       Bundle bundleDraft = null;
       MedicationRequest medReqDraft = null;
       try{
        if(body.get("context") == null) {
            throw new Exception("The required information must be included in the context.");
        }
        context = new LinkedHashMap((Map) body.get("context"));
        if(context.get("userId") == null) {
            throw new Exception("userId must be included in the context.");
        }
        if(context.get("patientId") == null) {
            throw new Exception("patientId must be included in the context.");
        }
        if(context.get("selections") == null) {
            throw new Exception("The selected drug must be included (selections).");
        }
        selection = ((ArrayList)context.get("selections")).get(0).toString();
        resource = selection.split("/")[0];
        resourceId = selection.split("/")[1];
        if(context.get("draftOrders") == null) {
            throw new Exception("Draft orders must be included (draftOrders).");
        }
       
        Gson gsonDraft = new Gson();
        String draft = gsonDraft.toJson(context.get("draftOrders"),LinkedHashMap.class);
        bundleDraft = iParser.parseResource(Bundle.class,draft);
        for (Bundle.BundleEntryComponent entry : bundleDraft.getEntry()) {
            if(entry.getResource().fhirType().equals(resource)) {
              medReqDraft = (MedicationRequest)entry.getResource();
              if(!medReqDraft.getId().split("/")[1].equals(resourceId)){
                throw new Exception("The selected drug (selections) doesn't match the one in the draft order");
              }
            }
        }
       }catch(Exception ex){
           throw new Exception(ex.getMessage());
       }
       
       LinkedHashMap prefetch = null;
       List<MedicationRequest> medReqActive = new ArrayList<>();
       Bundle bundleActive = null;
       try {
            if(body.get("prefetch") != null) {
              prefetch = new LinkedHashMap((Map) body.get("prefetch"));  
              if(prefetch.get("activeMedicationRequest") == null){
                  if(fhirServer == null || fhirAuthorization == null) {
                    throw new Exception("If the prefetch field is not sent, the FHIR server URL must be sent along with the credentials to access.");
                  }
              } else {
                  Gson gsonActive = new Gson();
                  String active = gsonActive.toJson(prefetch.get("activeMedicationRequest"),LinkedHashMap.class);
                  bundleActive = iParser.parseResource(Bundle.class,active);
                  for (Bundle.BundleEntryComponent entry : bundleActive.getEntry()) {
                    if(entry.getResource().fhirType().equals("MedicationRequest")) {
                        medReqActive.add((MedicationRequest)entry.getResource());
                    }
                  }
                }
              
              } else {
            
            
              }
       } catch(Exception ex) {
              throw new Exception(ex.getMessage());  
       }
       
       float activeDose = 0;
       List<String> activeMedIds = new ArrayList<>();
       
       for(MedicationRequest mq : medReqActive){
          activeDose += mq.getDosageInstructionFirstRep().getDoseAndRateFirstRep().getDoseQuantity().getValue().floatValue()
                        * mq.getDosageInstructionFirstRep().getTiming().getRepeat().getFrequency();
          activeMedIds.add(mq.getMedicationReference().getReference().split("/")[1]);
       }
       
       float draftDose = medReqDraft.getDosageInstructionFirstRep().getDoseAndRateFirstRep().getDoseQuantity().getValue().floatValue()
                          * medReqDraft.getDosageInstructionFirstRep().getTiming().getRepeat().getFrequency();
       
       String draftMedId = medReqDraft.getMedicationReference().getReference().split("/")[1];
       
       Medication draftMed = this.getMedication(fhirServer, draftMedId);
       String draftCode = draftMed.getCode().getCodingFirstRep().getCode();
               
       JSONObject card = new JSONObject();
       JSONObject cards = new JSONObject();
       JSONArray cardsArray = new JSONArray();
       
       for(String activeMedId : activeMedIds) {
           Medication activeMed = this.getMedication(fhirServer, activeMedId);
           String activeCode = activeMed.getCode().getCodingFirstRep().getCode();
           List<String> codeList = new ArrayList<>();
           codeList.add(draftCode);
           codeList.add(activeCode);
           
           codeList.retainAll(opioidsCodes);
           if(codeList.size() >=2){
               if(draftDose + activeDose >= 50) {
                   float remainderDose = 49 - activeDose;
                   card.put("summary","High risk of opioid overdose: decrease dose");
                   card.put("detail", "Reduce the total opioids dose to less than 50mg per day");
                   card.put("indicator","warning");
                   JSONArray sources = new JSONArray();
                   JSONObject source = new JSONObject();
                   source.put("label","Maximum Dose Calculation");
                   source.put("url", "https://www.cdc.gov/drugoverdose/pdf/calculating_total_daily_dose-a.pdf");
                   sources.put(source);
                   card.put("source", sources);
                   JSONArray suggestions = new JSONArray();
                   
                   JSONObject changeDose = new JSONObject();
                   changeDose.put("label","Modify Dose - maximum " + remainderDose + "mg more in day");
                   changeDose.put("uuid", UUID.randomUUID());
                   suggestions.put(changeDose);
                   
                   JSONObject cancelPrescription = new JSONObject();
                   cancelPrescription.put("label","Cancel Prescription");
                   cancelPrescription.put("uuid", UUID.randomUUID());
                   
                   JSONArray actions = new JSONArray();
                   JSONObject action = new JSONObject();
                   action.put("type","update");
                   action.put("description", "The prescription will be canceled");
                   Meta meta = new Meta();
                   CanonicalType canonical = new CanonicalType();
                   canonical.setValue("https://saintmartinhospital.org/fhir/StructureDefinition/MedicationRequest");
                   meta.setProfile( Collections.singletonList( canonical ) );
                   medReqDraft.setMeta(meta); 
                   medReqDraft.setAuthoredOn(null);
                   medReqDraft.setStatus(MedicationRequest.MedicationRequestStatus.CANCELLED);
                   iParser.setPrettyPrint(true);
                   action.put("resource", iParser.encodeResourceToString(medReqDraft));
                   actions.put(action);
                   
                   cancelPrescription.put("actions", actions);
                   suggestions.put(cancelPrescription);
                   card.put("suggestions",suggestions);
                   cardsArray.put(card);
                   break;
               }
           }
       }
       
       cards.put("cards",cardsArray);
       return cards.toString();
    }
    
    private Medication getMedication(String fhirServer, String medId){
       RestTemplate restTemplate = new RestTemplate();
       HttpHeaders headers = new HttpHeaders();
       headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        
       HttpEntity<String> entity = new HttpEntity<>("parameters", headers);
       String url = fhirServer + "/Medication/".concat(medId);
       
       HttpEntity<String> responseFHIR = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
       
       IParser iParser = FHIR_CTX.newJsonParser();
       Medication med = iParser.parseResource(Medication.class,responseFHIR.getBody());
       
       return med;
    }
}
