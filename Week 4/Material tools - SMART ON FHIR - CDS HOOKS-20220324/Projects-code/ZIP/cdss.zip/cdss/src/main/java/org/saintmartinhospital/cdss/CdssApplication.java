package org.saintmartinhospital.cdss;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CdssApplication {

	public static void main(String[] args) {
		SpringApplication.run(CdssApplication.class, args);
	}

}
