package org.saintmartinhospital.legacy.service.exceptions;


public class PrescriptionNotFoundException extends Exception {

	public PrescriptionNotFoundException() {
	}

	public PrescriptionNotFoundException(String msg) {
		super(msg);
	}
	
}
