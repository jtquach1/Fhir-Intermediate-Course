package org.saintmartinhospital.fhir.service.patient.converter.mappings;


public interface PatientNameMapping extends PatientDataMapping, PatientPopulator {
}
