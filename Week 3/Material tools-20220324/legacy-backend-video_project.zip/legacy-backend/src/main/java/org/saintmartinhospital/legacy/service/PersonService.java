package org.saintmartinhospital.legacy.service;

import java.util.List;
import org.saintmartinhospital.legacy.domain.Person;
import org.saintmartinhospital.legacy.service.bo.FindPersonByCriteriaBO;

public interface PersonService {
	
	Person findById( Integer id );
	List<Person> findByCriteria( FindPersonByCriteriaBO criteria );
    Person save( Person person );	
	
    Person attach( Person person );
	
}
