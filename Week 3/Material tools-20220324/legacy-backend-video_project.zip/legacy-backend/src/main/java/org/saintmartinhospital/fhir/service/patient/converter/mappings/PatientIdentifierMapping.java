package org.saintmartinhospital.fhir.service.patient.converter.mappings;


public interface PatientIdentifierMapping extends PatientDataMapping, PatientPopulator {
}
