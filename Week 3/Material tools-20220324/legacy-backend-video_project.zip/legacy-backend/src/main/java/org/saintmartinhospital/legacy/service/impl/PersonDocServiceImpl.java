package org.saintmartinhospital.legacy.service.impl;

import java.util.Calendar;
import org.saintmartinhospital.legacy.domain.DocType;
import org.saintmartinhospital.legacy.domain.PersonDoc;
import org.saintmartinhospital.legacy.repository.PersonDocRepository;
import org.saintmartinhospital.legacy.service.DocTypeService;
import org.saintmartinhospital.legacy.service.PersonDocService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;


@Component
public class PersonDocServiceImpl implements PersonDocService {
	
	@Autowired
	private PersonDocRepository personDocRepo;
	@Autowired
	private DocTypeService docTypeService;

	@Transactional
	@Override
	public PersonDoc save( PersonDoc personDoc ) {
		if( personDoc != null ) {
			DocType docType = docTypeService.findByAbrev( personDoc.getDocType().getAbrev() );
			if( docType == null )
				throw new IllegalArgumentException( String.format( "Document type %s not found", personDoc.getDocType().getAbrev() ) );
			
			personDoc.setDocType( docType );
			personDoc.setCreateDate( Calendar.getInstance() );
			personDoc = personDocRepo.save( personDoc );
		}
		return personDoc;
	}
	
}
