package org.saintmartinhospital.legacy.service;

import org.saintmartinhospital.legacy.domain.PersonDoc;


public interface PersonDocService {

	PersonDoc save( PersonDoc personDoc );
	
}
