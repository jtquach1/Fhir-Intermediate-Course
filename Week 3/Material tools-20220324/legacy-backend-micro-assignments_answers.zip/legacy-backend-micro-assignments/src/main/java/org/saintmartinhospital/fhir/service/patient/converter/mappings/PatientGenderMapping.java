package org.saintmartinhospital.fhir.service.patient.converter.mappings;


public interface PatientGenderMapping extends PatientDataMapping, PatientPopulator {
}
