package org.saintmartinhospital.legacy.domain;

public enum GenderEnum {
	FEMALE, MALE, OTHER
}
