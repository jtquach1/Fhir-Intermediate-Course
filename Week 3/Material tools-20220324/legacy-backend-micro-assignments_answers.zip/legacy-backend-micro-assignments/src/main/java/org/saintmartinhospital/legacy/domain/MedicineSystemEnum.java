package org.saintmartinhospital.legacy.domain;


public enum MedicineSystemEnum {
	RXNORM, SNOMED
}
