package org.saintmartinhospital.legacy.service.exceptions;


public class MedicineNotFoundException extends Exception {

	public MedicineNotFoundException() {
	}

	public MedicineNotFoundException(String msg) {
		super(msg);
	}
	
}
