package org.saintmartinhospital.fhir.service.patient.converter.mappings;


public interface PatientTelecomMapping extends PatientDataMapping {
}
